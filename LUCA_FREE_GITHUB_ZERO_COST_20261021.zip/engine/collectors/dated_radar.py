#!/usr/bin/env python3
"""Bounded real daily observation pilot. No orders, no production push, no PIT claim."""
import argparse, concurrent.futures, datetime as dt, hashlib, json, pathlib, statistics, urllib.parse
from radar import get_json, number, points, SOURCE_LOG, ROOT
from collect import Client, universe, now, write
from session_calendar import NY, latest_completed, close_at
SAFE={'entry_allowed':False,'entryAllowed':False,'precision_candidate_allowed':False,'simulationEligible':False,'simulationOnly':False,'entryStatus':'REVIEW_REQUIRED','entryScope':'REAL_ENTRY_BLOCKED','reviewEvidenceVerified':False,'validationStatus':'NOT_VALIDATED','validation_status':'NOT_VALIDATED','performance_verified':False}
def metrics(raw,session):
 r=raw['chart']['result'][0];q=r['indicators']['quote'][0];bars=[]
 for i,t in enumerate(r.get('timestamp',[])):
  stamp=dt.datetime.fromtimestamp(t,dt.timezone.utc);day=stamp.astimezone(NY).date().isoformat()
  if day>session:continue # Unfinished or future bars never enter calculations.
  vals=[q[k][i] for k in ['open','high','low','close','volume']]
  if any(number(v) is None for v in vals):continue
  o,h,l,c,v=vals
  if min(o,h,l,c)<=0 or v<0 or h<max(o,l,c) or l>min(o,h,c):raise ValueError('잘못된 일봉 숫자')
  bars.append({'t':stamp.isoformat(),'o':o,'h':h,'l':l,'c':c,'v':v})
 if len(bars)<21 or bars[-1]['t'][:10]!=session:raise ValueError('최신 완료 거래일 또는 20일 비교 자료 부족')
 dates=[b['t'][:10] for b in bars]
 if dates!=sorted(set(dates)):raise ValueError('일봉 날짜 중복/순서 오류')
 # Comparison window must contain each scheduled session (no suspended/missing days).
 expected=[];day=dt.date.fromisoformat(session)
 while len(expected)<21:
  if close_at(day):expected.append(day.isoformat())
  day-=dt.timedelta(days=1)
 if dates[-21:]!=list(reversed(expected)):raise ValueError('최근 21거래일 자료 누락')
 splits=r.get('events',{}).get('splits',{})
 if splits:raise ValueError('주식분할·병합 이력: 가격/거래량 단위 확인 전 차단')
 last=bars[-1];base=statistics.mean(b['v'] for b in bars[-21:-1])
 if base<=0 or last['v']<=0:raise ValueError('거래량 부족')
 return {'daily':bars[-30:],'price':last['c'],'volume':last['v'],'session':session,'rvol_daily':last['v']/base,'sma5':statistics.mean(b['c'] for b in bars[-6:-1]),'prior_high':max(b['h'] for b in bars[-6:-1]),'close_location':(last['c']-last['l'])/(last['h']-last['l']) if last['h']>last['l'] else .5,'split_events':splits,'daily_change_pct':(last['c']/bars[-2]['c']-1)*100,'quote_at':dt.datetime.fromtimestamp(r['meta']['regularMarketTime'],dt.timezone.utc).isoformat() if r['meta'].get('regularMarketTime') else None}
def crosscheck(j,ticker,session,m):
 data=j.get('data') or {}
 if data.get('symbol')!=ticker:raise ValueError('시세 출처 종목 불일치')
 rows=(data.get('tradesTable') or {}).get('rows') or [];matches=[]
 for r in rows:
  try:day=dt.datetime.strptime(r['date'],'%m/%d/%Y').date().isoformat()
  except (KeyError,TypeError,ValueError):continue
  if day==session:matches.append(r)
 if len(matches)!=1:raise ValueError('Nasdaq 완료 거래일 미확인/중복')
 p=number(matches[0].get('close'));v=number(matches[0].get('volume'))
 if not p or not v or p<=0 or v<=0:raise ValueError('Nasdaq 숫자 미확인')
 if abs(m['price']/p-1)>.01:raise ValueError('같은 거래일 가격 차이 1% 초과')
 if abs(m['volume']/v-1)>.05:raise ValueError('같은 거래일 거래량 차이 5% 초과')
 return {'nasdaq_session':session,'nasdaq_close':p,'nasdaq_volume':v,'nasdaq_raw_date':matches[0]['date']}
def signal(m):
 # Fixed before collection; observation hypotheses, NOT validated prediction rules.
 if not (.1<=m['price']<=20 and m['volume']>=100000):return 'none'
 ch=m['daily_change_pct'];rv=m['rvol_daily']
 if rv>=2 and 0<ch<=40 and m['price']>m['prior_high']:return 'confirmed_daily'
 if rv>=1.5 and 0<=ch<=10 and m['price']>m['sma5']:return 'early_daily'
 return 'none'
def no_signal_reason(m):
 if not .1<=m['price']<=20:return '이번 관찰 가격 범위($0.1~20) 밖입니다.'
 if m['volume']<100000:return '하루 거래량이 10만 주 미만입니다.'
 if m['daily_change_pct']<0:return '거래량이 늘어도 종가가 하락해 상승 관찰 조건에서 제외합니다.'
 if m['rvol_daily']<1.5:return '거래량이 평소의 1.5배에 못 미칩니다.'
 if m['price']<=m['sma5']:return '종가가 최근 5일 평균보다 높지 않습니다.'
 return '상승 폭 또는 최근 5일 고점 돌파 조건을 충족하지 못했습니다.'
def details(seed,session):
 ticker=seed['ticker'];base={**seed,**SAFE,'dataKind':'real-current-radar','id':seed['exchange']+':'+ticker+':'+session,'facts':{},'filings':[],'risk_hits':[],'risk_status':'SEC·증자·상장유지 미확인 · 매수 차단','sec_status':'NOT_REQUESTED','risk_register':{k:{'status':'UNKNOWN','reviewed':False,'sources':[]} for k in ['float','warrants','atm','convertibles','resale','listing','short_interest','ctb']},'market_cap':None,'microcap_status':'현재 시가총액 미확인 · 과거 소형주 표본','score':None,'parts':[],'reasons':[],'against':['현재 시총·Float 미확인. 초소형주 적격성 미확정.','SEC 원계약·증자·상장유지·공매도 미확인. 실전 매수 차단.'],'selection_lane':'date_unverified','screening_eligible':False,'signal_status':'DATA_BLOCKED','screener_asof':None,'price_screener':None,'source':'https://finance.yahoo.com/quote/'+ticker+'/history/','source_screener':'https://www.nasdaq.com/market-activity/stocks/'+ticker.lower()+'/historical'}
 try:
  u='https://query1.finance.yahoo.com/v8/finance/chart/'+urllib.parse.quote(ticker,safe='')+'?range=3mo&interval=1d&events=splits'
  raw=get_json(u);y_at=now()
  if raw['chart']['result'][0]['meta'].get('symbol')!=ticker:raise ValueError('Yahoo 종목 불일치')
  m=metrics(raw,session);base.update(m);base.update(points(m,{}))
  url='https://api.nasdaq.com/api/quote/'+urllib.parse.quote(ticker,safe='')+'/historical?'+urllib.parse.urlencode({'assetclass':'stocks','limit':5,'fromdate':(dt.date.fromisoformat(session)-dt.timedelta(days=8)).isoformat(),'todate':session})
  j=get_json(url);n_at=now();e=crosscheck(j,ticker,session,m)
  lane=signal(m);e.update({'method':'yahoo-nasdaq-historical-v1','yahoo_session':session,'yahoo_retrieved_at':y_at,'nasdaq_retrieved_at':n_at,'yahoo_url':u,'nasdaq_url':url,'regular_close_at':close_at(dt.date.fromisoformat(session)).isoformat(),'timestamp_basis':'가격은 출처의 거래일, 마감 시각은 거래소 달력. 다운로드 시각과 별개.'})
  return {**base,'dated_evidence':e,'quote_collected_at':n_at,'price_disagreement':False,'selection_lane':lane,'signal_status':'OBSERVATION_ONLY' if lane!='none' else 'NO_SIGNAL','screening_eligible':lane!='none','date_verified':True,'stage':'완료 일봉 관찰 · 실시간 매수 아님','reasons':[f"거래량이 앞선 20거래일 평균의 {m['rvol_daily']:.2f}배",f"같은 일봉 기준 등락 {m['daily_change_pct']:.2f}%",'관찰 조건 충족 · 현재 시총과 SEC 확인 전 매수 불가' if lane!='none' else no_signal_reason(m)]}
 except Exception as e:return {**base,'date_verified':False,'error':type(e).__name__+': '+str(e)[:140],'reasons':['자료 불확실: 후보 선정 차단'],'quote_collected_at':now()}
def main():
 p=argparse.ArgumentParser();p.add_argument('--seeds',default=str(ROOT/'config/dated-pilot-seeds.json'));p.add_argument('--limit',type=int,default=30);p.add_argument('--out',default='local-data/dated-pilot.json');a=p.parse_args()
 if not 20<=a.limit<=30:p.error('이번 수집은 20~30개만 허용합니다.')
 started=now();session=latest_completed(dt.datetime.now(dt.timezone.utc));seed=json.loads(pathlib.Path(a.seeds).read_text());chosen=seed['rows'][:a.limit]
 if len(chosen)!=a.limit or len({r['ticker'] for r in chosen})!=a.limit:raise ValueError('표본 수/중복 오류')
 # Directory is a current listing check, not a full-market quote scan.
 client=Client();listed={r['listings'][0]['ticker']:r for r in universe(client)}
 rows=[]
 def run(r):
  if r['ticker'] not in listed:return {**r,**SAFE,'date_verified':False,'screening_eligible':False,'signal_status':'DATA_BLOCKED','error':'현재 상장 보통주/ADR 목록에서 확인 불가'}
  current={**r,'exchange':listed[r['ticker']]['listings'][0]['exchange']}
  return details(current,session)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  for r in ex.map(run,chosen):
   rows.append(r);print(r['ticker'],r.get('signal_status'),r.get('error',''),flush=True)
   write(str(a.out)+'.progress.json',{'kind':'INCOMPLETE_COLLECTION','started_at':started,'rows':rows})
 valid=[r for r in rows if r.get('date_verified')];candidates=[r for r in valid if r['screening_eligible']]
 result={**SAFE,'schema_version':1,'kind':'real-current-radar','dataKind':'real-current-radar','collector_version':'dated-pilot-1','generated_at':now(),'collection_started_at':started,'session':session,'universe_count':len(listed),'eligible_count':None,'attempted_count':len(chosen),'success_count':len(valid),'detail_failure_count':len(rows)-len(valid),'not_evaluated_count':len(listed)-len(chosen),'screening_candidate_count':len(candidates),'signal_status':'OBSERVATION_ONLY' if candidates else 'NO_SIGNAL' if len(valid)==len(rows) else 'DATA_INCOMPLETE','candidates':valid[:20],'additional_rows':valid[20:]+[r for r in rows if not r.get('date_verified')],'source_receipts':SOURCE_LOG+client.log,'schedule_status':'중지 · 수동 수집 1회','actual_backtest_completed':False,'full_market_realtime':False,'method':'과거 소형주 추정 목록의 새 표본 30개 → 최신 상장 여부 → 완료 일봉 21거래일 → Nasdaq 같은 날짜 종가·거래량 대조 → 고정 관찰 조건','selection_method':seed['note'],'limitations':['현재 시총 미확인: 초소형주 적격성 검증 완료가 아닙니다.','SEC 원계약·Float·공매도 위험은 미확인. 모든 실전 매수 차단.','2026년 정규장 달력만 지원. 임시 휴장은 자동 예측하지 않으며 자료가 없으면 차단.','일봉 관찰 조건의 예측력·실제 거래 성과 NOT_VALIDATED.','자료 갱신은 수동. 다음 거래일 마감 후 오래된 자료의 후보 자격 해제.'],'errors':[{'ticker':r['ticker'],'error':r['error']} for r in rows if r.get('error')]}
 # Never overwrite last good output on total collection failure.
 target=pathlib.Path(a.out)
 if not valid:
  write(str(target)+'.failed.json',result);raise SystemExit('날짜 확인 성공 0개: 기존 정상 결과 유지. 실패 기록만 저장.')
 tmp=target.with_suffix(target.suffix+'.tmp');write(tmp,result);tmp.replace(target)
 print(json.dumps({'session':session,'attempted':len(rows),'date_verified':len(valid),'observations':len(candidates),'output':str(target)},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
