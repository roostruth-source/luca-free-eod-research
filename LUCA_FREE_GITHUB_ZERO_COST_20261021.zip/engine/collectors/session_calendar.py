"""2026 US cash-equity regular sessions. Unknown years fail closed.
Sources checked 2026-10-14: https://www.nasdaqtrader.com/trader.aspx?id=calendar
https://www.nyse.com/markets/hours-calendars
Unscheduled closures are not predicted; missing market bars still fail closed.
"""
import datetime as dt
from zoneinfo import ZoneInfo
NY=ZoneInfo('America/New_York')
HOLIDAYS=set('2026-01-01 2026-01-19 2026-02-16 2026-04-03 2026-05-25 2026-06-19 2026-07-03 2026-09-07 2026-11-26 2026-12-25'.split())
EARLY=set('2026-11-27 2026-12-24'.split())
def close_at(day):
 if day.year!=2026:raise ValueError('거래 달력 지원 범위 밖: 날짜 확인 전 차단')
 if day.weekday()>4 or day.isoformat() in HOLIDAYS:return None
 return dt.datetime.combine(day,dt.time(13 if day.isoformat() in EARLY else 16),NY)
def latest_completed(at):
 if at.tzinfo is None:raise ValueError('시간대 미확인')
 day=at.astimezone(NY).date()
 for _ in range(10):
  close=close_at(day)
  if close and at>=close:return day.isoformat()
  day-=dt.timedelta(days=1)
 raise ValueError('마지막 거래일 미확인')
def next_close(day):
 for offset in range(1,11):
  close=close_at(day+dt.timedelta(days=offset))
  if close:return close
 raise ValueError('다음 거래일 미확인')
