#!/usr/bin/env python3
"""Bounded, dated activity discovery. Frozen survey-1 formal rules are NOT tuned."""
import argparse,concurrent.futures,datetime as dt,hashlib,json,math,pathlib,uuid
from zoneinfo import ZoneInfo
from collect import Client,universe,now,write
from radar import get_json,SOURCE_LOG,ROOT
from survey import RULES,SAFE,append_record,fingerprint,lanes,light,detailed,shortlist
from session_calendar import latest_completed,close_at
from dated_radar import metrics

REFERENCE_RULES={'version':'movement-1','relative_volume_min':2,'absolute_change_min':5,'price_min':.1,'price_max':20,'volume_min':100000,'description':'정식 조건 탈락 종목의 별도 주의 관찰. 거래량 2배 이상 또는 절대 등락 5% 이상. 하락·이미 급등한 경우 포함. 수익 예측 가설 아님.'}
FEEDS=[('aggressive_small_caps',0),('aggressive_small_caps',250),('small_cap_gainers',0)]
RISKS='증자 계약·실제 유통주식수·공매도·상장유지 미확인. 실제 매수 불가.'

def reference_lanes(r):
 if r.get('light_status')=='DATA_BLOCKED':return []
 p,v,rv,ch=[r.get(k) for k in ['price','volume','rvol_daily','daily_change_pct']]
 if not all(isinstance(x,(int,float)) and math.isfinite(x) for x in [p,v,rv,ch]) or not .1<=p<=20 or v<100000:return []
 return (['volume_attention'] if rv>=2 else [])+(['price_attention'] if abs(ch)>=5 else [])

def failures(r):
 if r.get('light_status')=='DATA_BLOCKED':return {'자료':['거래일·일봉·분할/병합 단위 미확인']}
 p,v,rv,ch=[r[k] for k in ['price','volume','rvol_daily','daily_change_pct']];b=r['daily'];last=b[-3:]
 common=[]
 if not .1<=p<=20:common.append('가격이 0.1~20달러 범위 밖')
 if v<100000:common.append('하루 거래량이 10만 주 미만')
 checks={
 '완만한 상승':[(rv>=1.5,'거래량이 평소의 1.5배 미만'),(0<=ch<=10,'등락률이 0~10% 범위 밖'),(p>r['sma5'],'최근 5일 평균 종가 이하')],
 '고점 돌파':[(rv>=2,'거래량이 평소의 2배 미만'),(0<ch<=40,'등락률이 0% 초과~40% 범위 밖'),(p>r['prior_high'],'최근 5일 고점을 넘지 못함')],
 '급락 뒤 안정':[(p/max(x['h'] for x in b[-21:-1])-1<=-.25,'이전 20일 고점 대비 하락폭이 25% 미만'),(last[0]['l']<=last[1]['l']<=last[2]['l'],'최근 3일 저점이 다시 낮아짐'),(max(x['h'] for x in last)/min(x['l'] for x in last)-1<=.10,'최근 3일 가격 범위가 10% 초과'),(0<=ch<=5,'등락률이 0~5% 범위 밖'),(rv>=1,'거래량이 평소보다 적음')]}
 return {k:common+[msg for ok,msg in tests if not ok] for k,tests in checks.items()}

def feed_seed(q,session,at,url):
 """Quote epoch is mandatory. Collection time never substitutes for market time."""
 t=dt.datetime.fromtimestamp(q['regularMarketTime'],dt.timezone.utc);close=close_at(dt.date.fromisoformat(session))
 if latest_completed(at)!=session or t.astimezone(ZoneInfo('America/New_York')).date().isoformat()!=session or not close or not close<=at or t>at or not close<=t<=close+dt.timedelta(minutes=15):raise ValueError('정규장 마감 전 또는 기준일/마감 시각 미확인: 조사 순위 사용 차단')
 p,v,ch,cap=[q.get(k) for k in ['regularMarketPrice','regularMarketVolume','regularMarketChangePercent','marketCap']]
 if not all(isinstance(x,(int,float)) and math.isfinite(x) for x in [p,v,ch,cap]) or not .1<=p<=20 or v<=0 or not 0<cap<=300e6:raise ValueError('조사 범위 밖 또는 숫자 미확인')
 avg=q.get('averageDailyVolume3Month');rv=v/avg if isinstance(avg,(int,float)) and math.isfinite(avg) and avg>0 else None
 return {'ticker':q['symbol'],'name':q.get('longName') or q.get('shortName') or q['symbol'],'priority_change_pct':ch,'priority_rvol':rv,'priority_volume':v,'priority_quote_at':t.isoformat(),'priority_source':url,'priority_basis':'날짜 확인 공개 순위 · 3개월 평균 대비 거래량(일봉 20일 기준과 다름)','discovery_market_cap_estimate':cap}

def prioritize(rows,count):
 """Interleave mild rising activity, volume increase, absolute movers. No hash sampling."""
 by={}
 for r in rows:
  # Fresh feed first, then same-session immutable previous evidence.
  by.setdefault(r['ticker'],r)
 rv=lambda r:r.get('priority_rvol') or 0
 buckets=[sorted([r for r in by.values() if 0<=r['priority_change_pct']<=10 and rv(r)>=1],key=lambda r:(-rv(r),r['ticker'])),sorted(by.values(),key=lambda r:(-rv(r),-r['priority_volume'],r['ticker'])),sorted(by.values(),key=lambda r:(-abs(r['priority_change_pct']),-r['priority_volume'],r['ticker']))]
 out=[];seen=set()
 while len(out)<count:
  before=len(out)
  for bucket in buckets:
   while bucket and bucket[0]['ticker'] in seen:bucket.pop(0)
   if bucket and len(out)<count:
    r=bucket.pop(0);out.append(r);seen.add(r['ticker'])
  if len(out)==before:break
 return out

def archived_seeds(history,session,at):
 """Reuse only post-close, source-backed completed daily bars; never invent quote time."""
 def stamp(value):
  t=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
  if t.tzinfo is None or t.utcoffset() is None:raise ValueError('시간대 누락')
  return t
 root=pathlib.Path(history).resolve();out=[];proof=[];close=close_at(dt.date.fromisoformat(session))
 if at.tzinfo is None or not close or latest_completed(at)!=session:raise ValueError('완료 거래일/조회 시각 미확인')
 for p in sorted(root.glob('runs/*/manifest.json'),reverse=True):
  m=json.loads(p.read_text());s=(root/m['selection_file']).resolve()
  if not s.is_relative_to(root):raise ValueError('관찰 기록 경로 오류')
  raw=s.read_bytes()
  if hashlib.sha256(raw).hexdigest()!=m['selection_sha256']:raise ValueError('과거 관찰 원본 지문 불일치')
  d=json.loads(raw)
  if d.get('session')!=session:continue
  note={'file':m['selection_file'],'sha256':m['selection_sha256'],'selection_known_at':d.get('selection_known_at'),'status':'UNCONFIRMED','accepted_count':0,'excluded_rows':[]};proof.append(note)
  try:
   known=stamp(d['selection_known_at'])
   if not close<=known<=at:raise ValueError('마감 전 작성 또는 미래 기록')
   if d.get('kind')!='real-current-radar' or d.get('collector_version') not in ['survey-1','movement-1']:raise ValueError('실제 일봉 관찰 기록 형식 미확인')
  except (ValueError,KeyError,TypeError,AttributeError) as e:
   note['reason']=str(e);continue
  for r in d.get('light_results',[]):
   if r.get('light_status')=='DATA_BLOCKED':continue
   try:
    if r.get('session')!=session:raise ValueError('행 거래일 불일치')
    received=stamp(r['yahoo_retrieved_at'])
    if not close<=received<=known:raise ValueError('일봉 수집이 마감 전 또는 선정 후')
    receipts=[x for x in d.get('source_receipts',[]) if x.get('url')==r.get('yahoo_url')]
    if len(receipts)!=1:raise ValueError('원문 출처 영수증 누락/중복')
    rec=receipts[0];receipt_time=stamp(rec['retrieved_at'])
    if not close<=receipt_time<=received:raise ValueError('원문 수집 시각 불일치')
    digest=rec['sha256']
    if not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):raise ValueError('원문 지문 형식 오류')
    source=(p.parent/'source-raw'/(digest+'.raw')).read_bytes()
    if len(source)!=rec['bytes'] or hashlib.sha256(source).hexdigest()!=digest:raise ValueError('원문 무결성 불일치')
    j=json.loads(source)
    if j['chart']['result'][0]['meta'].get('symbol')!=r['ticker']:raise ValueError('원문 종목 불일치')
    calc=metrics(j,session)
    if r.get('daily')!=calc['daily']:raise ValueError('저장 일봉과 원문 일치 미확인')
    for key in ['price','volume','daily_change_pct','rvol_daily','sma5','prior_high']:
     v=r.get(key)
     if not isinstance(v,(int,float)) or not math.isfinite(v) or not math.isclose(v,calc[key],rel_tol=1e-10,abs_tol=1e-10):raise ValueError('저장 수치와 원문 재계산 불일치: '+key)
    out.append({'ticker':r['ticker'],'name':r['name'],'priority_change_pct':calc['daily_change_pct'],'priority_rvol':calc['rvol_daily'],'priority_volume':calc['volume'],'priority_quote_at':None,'priority_session':session,'priority_bar_at':calc['daily'][-1]['t'],'priority_available_at':d['selection_known_at'],'priority_calendar_close_at':close.isoformat(),'priority_source':'sha256:'+m['selection_sha256'],'priority_source_url':r['yahoo_url'],'priority_source_sha256':digest,'priority_basis':'마감 후 보관된 완료 일봉 원문·수치 재검증. 거래 시각은 부여하지 않음. 달력 마감은 경계 시각일 뿐 실제 체결 시각 아님.'})
    note['accepted_count']+=1
   except (ValueError,KeyError,TypeError,AttributeError,IndexError,OSError) as e:
    note['excluded_rows'].append({'ticker':r.get('ticker'),'status':'UNCONFIRMED','reason':str(e)[:160]})
  if note['accepted_count']:note['status']='COMPLETED_DAILY_SOURCE_CHECKED'
 return out,proof

def detail_budget(rows,limit):
 formal=shortlist(rows,limit)
 reference=sorted([r for r in rows if not r['discovery_lanes'] and r['reference_lanes']],key=lambda r:(-r['rvol_daily'],-abs(r['daily_change_pct']),r['ticker']))
 # Formal keeps first priority; never exceeds the shared detail cap.
 return formal+reference[:max(0,limit-len(formal))]

def run(count,limit,out,previous,*,allow_partial=False):
 if allow_partial and (count>100 or limit>25):raise ValueError('연구 모드 상한 초과: 조사 100개·상세 25개 이하만 허용')
 if not 80<=count<=120 or not 20<=limit<=30:raise ValueError('1차 80~120개, 상세 상한 20~30개만 허용')
 SOURCE_LOG.clear();out=pathlib.Path(out);started=now();at=dt.datetime.fromisoformat(started.replace('Z','+00:00'));session=latest_completed(at);run_id=started.replace(':','-')+'-'+uuid.uuid4().hex[:8]
 rule_doc={'fixed_before_collection_at':started,'priority_time_rule':'completed-close-v2','formal_rules':RULES,'formal_rules_sha256':fingerprint(RULES),'reference_rules':REFERENCE_RULES,'reference_rules_sha256':fingerprint(REFERENCE_RULES),'collector_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'source_hashes':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['collectors/survey.py','collectors/dated_radar.py','collectors/session_calendar.py']},'validation':'사전 등록 관찰 규칙. 과거 성공에 맞춘 최적화 아님. 향후 별도 검증 필요.'}
 append_record(out/'runs'/run_id/'rules.json',rule_doc)
 client=Client();securities=universe(client);listed={s['listings'][0]['ticker']:s for s in securities};seeds=[];excluded=[];feed_errors=[]
 for feed,start in FEEDS:
  url=f'https://query1.finance.yahoo.com/v1/finance/screener/predefined/saved?scrIds={feed}&count=250&start={start}'
  try:
   quotes=get_json(url)['finance']['result'][0]['quotes'];received=dt.datetime.fromisoformat(now().replace('Z','+00:00'))
   for q in quotes:
    try:
     r=feed_seed(q,session,received,url)
     if r['ticker'] not in listed:raise ValueError('현재 대상 거래소 보통주/ADR 명부에서 확인 못함')
     seeds.append(r)
    except (ValueError,KeyError,TypeError,OverflowError) as e:excluded.append({'ticker':q.get('symbol'),'source':url,'reason':str(e)})
  except Exception as e:feed_errors.append({'source':url,'error':type(e).__name__})
 prior,proof=archived_seeds(previous,session,at);seeds.extend(r for r in prior if r['ticker'] in listed)
 chosen=prioritize(seeds,count)
 population={'selection_method':'같은 거래일 자료에서 완만한 상승+거래 증가 / 상대 거래량 / 절대 등락 순위를 교차 선택. 무작위·해시 표본 미사용.','current_directory_count':len(listed),'dated_pool_count':len({r['ticker'] for r in seeds}),'feed_rows_accepted':len(seeds)-sum(r['ticker'] in listed for r in prior),'previous_same_session_evidence':proof,'light_limit':count,'detail_limit':limit,'chosen':chosen,'feed_exclusions':excluded,'feed_errors':feed_errors,'not_sampled_tickers':sorted({r['ticker'] for r in seeds}-{r['ticker'] for r in chosen}),'caveat':'공개 순위 목록의 부분 표본. 전체 시장·현재 초소형주 적격성 미검증. 현재 시총은 확정하지 않음.'}
 append_record(out/'runs'/run_id/'population.json',population)
 if len(chosen)<80 and not allow_partial:raise ValueError('날짜 확인 조사 대상이 80개 미만: 임의/오래된 표본으로 보충하지 않음. 마지막 정상 자료 유지.')
 if not chosen:raise ValueError('날짜 확인 조사 대상 0개: 조사 불가. 후보 0개 성공으로 처리하지 않음.')
 rows=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  enriched=[{**r,'exchange':listed[r['ticker']]['listings'][0]['exchange']} for r in chosen]
  for i,r in enumerate(ex.map(lambda x:light(x,session),enriched)):
   r.update(movement_rule_version='movement-1',reference_lanes=reference_lanes(r),formal_failures=failures(r),observation_grade='D',risk_summary=RISKS,selection_known_at=None)
   r['microcap_status']='현재 초소형주 적격성 미확인 · 거래 움직임 우선 조사';rows.append(r);append_record(out/'runs'/run_id/'light'/f'{i:03}.json',r)
   if (i+1)%10==0:print('날짜 확인 일봉 조사',i+1,'/',len(chosen),flush=True)
 picked=detail_budget(rows,limit);details=[]
 for r in picked:
  item=detailed(r,session);good=item['date_verified'];formal=bool(r['discovery_lanes']);item.update(observation_group='formal' if formal else 'reference',reference_eligible=good and not formal,screening_eligible=good and formal,observation_grade=('B' if formal else 'C') if good else 'D',risk_summary=RISKS)
  if not formal:item['reasons']=[f"거래량 {r['rvol_daily']:.2f}배 · 등락 {r['daily_change_pct']:.2f}%: 추가 관찰일 뿐, 정식 후보 아님"]
  details.append(item);print('상세 대조',r['ticker'],item['observation_grade'],item.get('error',''),flush=True)
 selected=now();rolled=latest_completed(dt.datetime.fromisoformat(selected.replace('Z','+00:00')))!=session
 for r in details:
  r['selection_known_at']=selected
  if rolled:r.update(date_verified=False,screening_eligible=False,reference_eligible=False,observation_grade='D',error='조사 중 다음 장 마감: 이전 일봉 사용 차단')
 formal=[r for r in details if r['screening_eligible']];refs=[r for r in details if r['reference_eligible']];blocked=[r for r in details if not r['date_verified']]
 result={**SAFE,'schema_version':1,'kind':'real-current-radar','dataKind':'real-current-radar','collector_version':'movement-1','generated_at':selected,'collection_started_at':started,'selection_known_at':selected,'session':session,'run_id':run_id,'rules_snapshot':rule_doc,'population':population,'universe_count':len(listed),'eligible_count':None,'attempted_count':len(rows),'success_count':sum(r['light_status']!='DATA_BLOCKED' for r in rows),'not_evaluated_count':len(population['not_sampled_tickers']),'light_qualified_count':sum(bool(r['discovery_lanes']) for r in rows),'light_reference_count':sum(bool(r['reference_lanes']) and not r['discovery_lanes'] for r in rows),'detail_attempted_count':len(details),'detail_failure_count':len(blocked),'detail_limit':limit,'screening_candidate_count':len(formal),'reference_count':len(refs),'candidates':formal[:20],'additional_rows':formal[20:]+refs,'rejected_details':blocked,'light_results':rows,'source_receipts':SOURCE_LOG+client.log,'errors':feed_errors+[{'ticker':r['ticker'],'error':r['error']} for r in rows+details if r.get('error')],'actual_backtest_completed':False,'full_market_realtime':False,'schedule_status':'중지 · 수동 조사','method':'날짜가 확인된 움직임 우선 조사 → 기존 정식 기준과 별도 추가 관찰 비교 → 최대 '+str(limit)+'개 두 출처 대조','selection_method':population['selection_method'],'limitations':[population['caveat'],RISKS,'일봉 마감 뒤 관찰. 급등 전 포착·실제 수익률 NOT_VALIDATED.','A등급 미사용. B=정식 일봉 조건 관찰, C=추가 관찰, D=미확인/차단. 전부 매수 불가.','현재 1거래일 기록. 3~5거래일의 미래 기록은 아직 없음.']}
 if allow_partial:
  coverage='DATA_UNAVAILABLE' if not result['success_count'] else ('PARTIAL' if result['success_count']<count else 'TARGET_MET')
  result.update(research_track='partial-coverage-v1',coverage_status=coverage,requested_light_count=count,available_seed_count=len(chosen),shortfall_count=max(0,count-result['success_count']),counts_as_frozen_five_session=False,coverage_notice=f"목표 {count}개 · 조사 {len(chosen)}개 · 일봉 확인 {result['success_count']}개. 조사 범위와 매수 안전성은 별개. 기존 5거래일 시험에 합산하지 않음.")
  result['limitations'].append(result['coverage_notice'])
 path=out/'selections'/session/(run_id+'.json');append_record(path,result)
 rawdir=out/'runs'/run_id/'source-raw';rawdir.mkdir()
 for rec in result['source_receipts']:
  raw=(ROOT/'cache'/(rec['sha256']+'.raw')).read_bytes()
  if hashlib.sha256(raw).hexdigest()!=rec['sha256']:raise ValueError('원본 지문 불일치')
  (rawdir/(rec['sha256']+'.raw')).write_bytes(raw)
 manifest={'selection_file':str(path.relative_to(out)),'selection_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'session':session,'selected_at':selected,'candidate_count':len(formal),'reference_count':len(refs)};append_record(out/'runs'/run_id/'manifest.json',manifest)
 if result['success_count'] and not rolled:
  tmp=out/'latest.tmp';write(tmp,result);tmp.replace(out/'latest.json')
 print(json.dumps({'light':len(rows),'valid':result['success_count'],'formal':len(formal),'reference':len(refs),'details':len(details),'blocked':len(blocked),'selection_file':str(path),'selection_sha256':manifest['selection_sha256']},ensure_ascii=False),flush=True)
 return result

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--light-limit',type=int,default=100);p.add_argument('--detail-limit',type=int,default=25);p.add_argument('--out',default='local-data/movement-history');p.add_argument('--previous',default='local-data/survey-history');a=p.parse_args();run(a.light_limit,a.detail_limit,a.out,a.previous)
