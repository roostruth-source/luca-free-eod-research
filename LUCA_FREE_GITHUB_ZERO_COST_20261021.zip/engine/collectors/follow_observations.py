#!/usr/bin/env python3
"""Append later DAILY outcomes. Never edits selection files; never simulates fills."""
import argparse,datetime as dt,hashlib,json,pathlib,urllib.parse,uuid
from collect import now
from radar import get_json,SOURCE_LOG,ROOT
from session_calendar import latest_completed,close_at
from survey import append_record,SAFE

def evaluate(selection,row,raw,observed_at):
 known=dt.datetime.fromisoformat(selection['selection_known_at'].replace('Z','+00:00'))
 at=dt.datetime.fromisoformat(observed_at.replace('Z','+00:00'))
 if at<=known:raise ValueError('이후 관찰 시각이 선정 시각보다 늦어야 합니다.')
 data=raw['chart']['result'][0]
 if data['meta'].get('symbol')!=row['ticker']:raise ValueError('종목 불일치')
 if data.get('events',{}).get('splits'):raise ValueError('분할·병합 단위 미확인: 이후 수익률 차단')
 q=data['indicators']['quote'][0];bars=[];last_session=latest_completed(at)
 for i,t in enumerate(data.get('timestamp',[])):
  day=dt.datetime.fromtimestamp(t,dt.timezone.utc).date();close=close_at(day)
  if day.isoformat()<=selection['session'] or day.isoformat()>last_session or not close or close<=known:continue
  c=q['close'][i];h=q['high'][i];l=q['low'][i]
  if not all(isinstance(x,(int,float)) and x>0 for x in [c,h,l]) or not l<=c<=h:raise ValueError('이후 일봉 숫자 오류')
  bars.append({'session':day.isoformat(),'close':c,'high':h,'low':l})
 if len({b['session'] for b in bars})!=len(bars) or bars!=sorted(bars,key=lambda b:b['session']):raise ValueError('이후 일봉 중복/순서 오류')
 # Explicit expected future sessions prevent missing days being treated as complete follow-up.
 expected=[];day=dt.date.fromisoformat(selection['session'])+dt.timedelta(days=1)
 while day.isoformat()<=last_session:
  c=close_at(day)
  if c and c>known:expected.append(day.isoformat())
  day+=dt.timedelta(days=1)
 if [b['session'] for b in bars]!=expected:raise ValueError('이후 거래일 자료 누락')
 if not bars:return {'status':'WAITING_FOR_FUTURE_SESSION','future_bars':[]}
 p=row['price'];peak=max(b['high'] for b in bars)
 return {'status':'DAILY_PATH_ONLY','future_bars':bars,'basis_price':p,'basis':'선정 당시 완료 일봉 종가. 실제 매수가 아님.','future_high_change_pct':(peak/p-1)*100,'reached_40pct_high':peak>=p*1.4,'latest_close_change_pct':(bars[-1]['close']/p-1)*100,'executable_5pct':None,'executable_10pct':None,'verified_trades':0,'limitations':'Yahoo 이후 일봉 관찰. 호가·스프레드·체결·수수료 미검증. 실제 거래 성과 아님.'}
def follow(selection_file,expected_sha,out):
 p=pathlib.Path(selection_file);original=p.read_bytes();sha=hashlib.sha256(original).hexdigest()
 if sha!=expected_sha:raise ValueError('선정 원본 SHA256 불일치: 추적 중단')
 d=json.loads(original)
 if d.get('kind')!='real-current-radar' or d.get('collector_version') not in ['survey-1','movement-1']:raise ValueError('실제 survey/movement 선정 기록만 추적')
 at=now();session=latest_completed(dt.datetime.fromisoformat(at.replace('Z','+00:00')));results=[]
 for r in d['candidates']+d.get('additional_rows',[]):
  eligible=r.get('screening_eligible') or (d['collector_version']=='movement-1' and r.get('reference_eligible') and r.get('observation_group')=='reference')
  if not eligible or not r.get('date_verified') or r.get('entry_allowed') is not False:raise ValueError('선정 기록 상태 오류')
  item={**SAFE,'ticker':r['ticker'],'observation_group':r.get('observation_group','formal')}
  if session<=d['session']:item['status']='WAITING_FOR_FUTURE_SESSION'
  else:
   try:
    url='https://query1.finance.yahoo.com/v8/finance/chart/'+urllib.parse.quote(r['ticker'],safe='')+'?range=3mo&interval=1d&events=splits'
    raw=get_json(url);item.update(evaluate(d,r,raw,at));item['source_url']=url
   except Exception as e:item.update(status='DATA_BLOCKED',error=type(e).__name__+': '+str(e)[:120])
  results.append(item)
 output={**SAFE,'kind':'real-observation-followup','selection_sha256':sha,'selection_file':p.name,'selection_known_at':d['selection_known_at'],'observed_at':at,'latest_completed_session':session,'candidates':results,'candidate_count':len(results),'source_receipts':SOURCE_LOG,'status':'NO_SELECTION_CANDIDATES' if not results else 'WAITING_OR_DAILY_ONLY','real_trade_count':0,'hit_rate':None}
 name=at.replace(':','-')+'-'+uuid.uuid4().hex[:8]+'.json';dest=pathlib.Path(out)/name;append_record(dest,output)
 rawdir=pathlib.Path(out)/(name+'.raw');rawdir.mkdir()
 for rec in SOURCE_LOG:
  raw=(ROOT/'cache'/(rec['sha256']+'.raw')).read_bytes()
  if hashlib.sha256(raw).hexdigest()!=rec['sha256']:raise ValueError('원자료 지문 불일치')
  (rawdir/(rec['sha256']+'.raw')).write_bytes(raw)
 assert p.read_bytes()==original
 print(json.dumps({'output':str(dest),'candidate_count':len(results),'statuses':[r['status'] for r in results],'selection_unchanged':True},ensure_ascii=False),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--selection',required=True);p.add_argument('--sha256',required=True);p.add_argument('--out',default='local-data/survey-history/outcomes');a=p.parse_args();follow(a.selection,a.sha256,a.out)
