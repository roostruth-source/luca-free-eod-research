#!/usr/bin/env python3
"""Read-only free current-market radar; never turns downloaded current data into PIT history."""
import argparse, concurrent.futures, datetime as dt, hashlib, json, math, os, pathlib, re, statistics, time, urllib.parse, urllib.request, uuid
from collect import Client, now, write, universe, sec
from zoneinfo import ZoneInfo
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCE_LOG=[]
COLLECTOR_SHA256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
def number(x):
 try:
  n=float(re.sub(r'[$,% ,]','',str(x)));return n if math.isfinite(n) else None
 except (ValueError,TypeError):return None
def get_json(url):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'LucaMicrocap/1.1 personal-research','Accept':'application/json'}),timeout=20) as r: raw=r.read()
 digest=hashlib.sha256(raw).hexdigest();cache=ROOT/'cache';cache.mkdir(exist_ok=True);(cache/(digest+'.raw')).write_bytes(raw)
 SOURCE_LOG.append({'url':url,'retrieved_at':now(),'sha256':digest,'bytes':len(raw)})
 return json.loads(raw)
def market_metrics(r):
 result=r['chart']['result'][0];q=result['indicators']['quote'][0];points=[]
 for i,t in enumerate(result.get('timestamp',[])):
  vals=[q[k][i] for k in ['open','high','low','close','volume']]
  if any(v is None for v in vals):continue
  points.append({'t':dt.datetime.fromtimestamp(t,dt.timezone.utc).isoformat(),'o':vals[0],'h':vals[1],'l':vals[2],'c':vals[3],'v':vals[4]})
 # Do not compare an unfinished day with full prior-day volumes.
 ny_now=dt.datetime.now(ZoneInfo('America/New_York'))
 if points and points[-1]['t'][:10]==ny_now.date().isoformat() and ny_now.hour<16:points.pop()
 if len(points)<6:raise ValueError('완료된 거래일 비교 자료 부족')
 last=points[-1];previous=points[-21:-1];base=statistics.mean(p['v'] for p in previous)
 avg5=statistics.mean(p['c'] for p in points[-6:-1]);prior_high=max(p['h'] for p in points[-6:-1]);mt=result['meta'].get('regularMarketTime');quote_at=dt.datetime.fromtimestamp(mt,dt.timezone.utc).isoformat() if mt else None
 return {'daily':points[-30:],'price':last['c'],'session':last['t'][:10],'quote_at':quote_at,'rvol_daily':last['v']/base if base>0 else None,'volume':last['v'],'sma5':avg5,'prior_high':prior_high,'close_location':(last['c']-last['l'])/(last['h']-last['l']) if last['h']>last['l'] else .5,'split_events':result.get('events',{}).get('splits',{}),'data_source':'Yahoo Finance 공개 차트 · 공식 보장 API 아님','source':'https://finance.yahoo.com/quote/'+urllib.parse.quote(result['meta']['symbol'])+'/history/','limitation':'현재 다운로드 버전. 과거 시점 원본으로 간주하지 않음. 일봉이며 VWAP/실시간 호가 아님.'}
def points(m,quote):
 # Fixed, untuned end-of-day ranking; not the intraday scoring engine.
 values=[]
 def add(name,w,p):values.append({'name':name,'weight':w,'points':round(p,1) if p is not None else None})
 add('완료일 일평균 상대거래량',30,30*max(0,min(1,(m['rvol_daily']-1)/4)) if m['rvol_daily'] is not None else None)
 add('최근 5일 가격 추세',20,20 if m['price']>m['sma5'] else 0)
 add('최근 5일 고점 돌파',15,15 if m['price']>m['prior_high'] else 0)
 add('당일 범위 내 종가 위치',15,15*m['close_location'])
 # Exact turnover is not inferred from close*volume. No points are assigned without trades/VWAP.
 add('실제 거래대금',10,None);add('확인된 Float',5,None);add('검토된 뉴스 촉매',5,None)
 return {'score':round(sum(p['points'] or 0 for p in values)),'coverage':sum(p['weight'] for p in values if p['points'] is not None),'parts':values}
def select_balanced(eligible,limit):
 """Four independent current-screener lanes; never claim to predict future moves.
 All selection variables are from the SAME present-day screener snapshot.
 This is NOT point-in-time historical backtesting.
 """
 if limit < 0:raise ValueError('limit must be >= 0 (0 means all eligible)')
 if limit == 0:limit=len(eligible)
 # Price*volume / cap is a *proxy* for turnover, not official dollar volume.
 for r in eligible:
  r['turnover_proxy']=r['price_screener']*r['volume_screener']/r['market_cap']
 lanes={
  'momentum':sorted(eligible,key=lambda r:(abs(r['change_pct'] or 0),r['volume_screener'],r['ticker']),reverse=True),
  'quiet_liquid':sorted((r for r in eligible if r['change_pct'] is not None and abs(r['change_pct'])<=5),key=lambda r:(r['volume_screener'],r['ticker']),reverse=True),
  'turnover_proxy':sorted(eligible,key=lambda r:(r['turnover_proxy'],r['volume_screener'],r['ticker']),reverse=True),
  'broad_sample':sorted(eligible,key=lambda r:hashlib.sha256(r['ticker'].encode()).hexdigest()),
 }
 names=list(lanes);selected=[];seen=set();quotas={n:limit//len(names)+(i<limit%len(names)) for i,n in enumerate(names)}
 for name in names:
  for r in lanes[name]:
   if quotas[name]<=0:break
   if r['ticker'] in seen:continue
   selected.append({**r,'selection_lane':name});seen.add(r['ticker']);quotas[name]-=1
 # Small lane may be exhausted; fill unused budget deterministically.
 for r in lanes['broad_sample']:
  if len(selected)>=limit:break
  if r['ticker'] not in seen:selected.append({**r,'selection_lane':'fill'});seen.add(r['ticker'])
 return selected

def require_screener_time(value,reference=None):
 """Conservative gate: missing/ambiguous/intraday/older than 24h must not select stocks."""
 try:
  t=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
  if t.tzinfo is None:raise ValueError('timezone missing')
  ref=reference or dt.datetime.now(dt.timezone.utc);age=(ref-t).total_seconds();ny=t.astimezone(ZoneInfo('America/New_York'))
  if not 0<=age<=86400 or (ny.hour,ny.minute)!=(16,0):raise ValueError('not fresh dated regular close')
  return ny.date().isoformat()
 except (AttributeError,TypeError,ValueError):raise ValueError('스크리너 기준일 미확인/오래된 시세: 후보 선정 중단. 마지막 정상 자료 유지. 날짜가 확인된 정규장 종가 필요.')

def discover(limit):
 c=Client();securities=universe(c);symbols={s['listings'][0]['ticker']:s for s in securities}
 j=get_json('https://api.nasdaq.com/api/screener/stocks?tableonly=true&limit=10000&download=true');screen_session=require_screener_time(j['data'].get('asOf'));eligible=[]
 for r in j['data']['rows']:
  s=symbols.get(r['symbol']);price=number(r.get('lastsale'));cap=number(r.get('marketCap'));volume=number(r.get('volume'));change=number(r.get('pctchange'))
  if not s or price is None or cap is None or volume is None or not(.1<=price<=20 and 0<cap<=300e6 and volume>=100000):continue
  eligible.append({'id':s['id'],'ticker':r['symbol'],'name':r['name'],'exchange':s['listings'][0]['exchange'],'price_screener':price,'market_cap':cap,'volume_screener':volume,'change_pct':change,'screener_session':screen_session,'screener_asof':j['data'].get('asOf'),'screener_collected_at':SOURCE_LOG[-1]['retrieved_at'],'source_screener':'https://www.nasdaq.com/market-activity/stocks/screener'})
 eligible.sort(key=lambda r:r['ticker'])
 return securities,eligible,select_balanced(eligible,limit)
def details(r):
 try:
  m=market_metrics(get_json('https://query1.finance.yahoo.com/v8/finance/chart/'+urllib.parse.quote(r['ticker'],safe='')+'?range=3mo&interval=1d&events=splits'))
  if r.get('screener_session')!=m['session']:raise ValueError('기준일이 달라 후보 선정 제외')
  disagreement=abs(m['price']/r['price_screener']-1)>.1
  return {**r,**m,**points(m,r),'quote_collected_at':now(),'price_disagreement':disagreement,'price_gap_pct':(m['price']/r['price_screener']-1)*100,'ranking_status':'PROVISIONAL_PRICE_MISMATCH' if disagreement else 'UNVERIFIED_SOURCE_TIME','precision_candidate_allowed':False,'stage':'일봉 관찰 · 장중 확인 아님','entry_allowed':False,'facts':{},'filings':[],'risk_hits':[],'risk_status':'SEC 미검토 · 위험 점수 미확인','reasons':[f"최근 일평균 대비 거래량 {m['rvol_daily']:.2f}배" if m['rvol_daily'] else '거래량 비교 불가','최근 5일 평균가격 위' if m['price']>m['sma5'] else '최근 5일 평균가격 아래'],'against':['VWAP·최신 호가·체결강도 미확인','Float·등록 매도 가능 물량 수동 검토 필요','소스 간 가격 차이 10% 초과: 수동 점검 필요' if disagreement else '가격 정보는 지연되거나 오래됐을 수 있음']}
 except Exception as e:return {**r,'quote_collected_at':now(),'error':type(e).__name__+': '+str(e)[:100]}
def sec_enrich(rows,limit,agent):
 run_id=uuid.uuid4().hex
 for row in rows:
  if row.get('facts') or row.get('filings'):
   row.setdefault('sec_history',[]).append({k:row.get(k) for k in ['sec_run_id','sec_status','sec_collected_at','facts','filings','risk_hits']})
  row['facts']={};row['filings']=[];row['risk_hits']=[]
  row['sec_status']='NOT_REQUESTED';row['sec_run_id']=run_id
  row['risk_register']={k:{'status':'UNKNOWN','reviewed':False,'sources':[]} for k in ['float','warrants','atm','convertibles','resale','listing','short_interest','ctb']}
 if not agent:
  for row in rows:row['sec_status']='SKIPPED_NO_IDENTITY'
  return ['SEC 연락 식별 환경변수 미설정: 자동 공시 보완 생략']
 c=Client(agent)
 try: mapping=c.json('https://www.sec.gov/files/company_tickers_exchange.json')
 except Exception as e:
  for row in rows[:limit]:row['sec_status']='MAPPING_FAILED';row['sec_collected_at']=now()
  return ['SEC mapping: '+type(e).__name__]
 cols=mapping['fields'];by={dict(zip(cols,r))['ticker']:dict(zip(cols,r))['cik'] for r in mapping['data']};errors=[]
 for row in rows[:limit]:
  log_start=len(c.log);row['sec_started_at']=now();row['risk_hits']=[]
  cik=by.get(row['ticker'])
  if not cik:row['sec_status']='CIK_UNKNOWN';errors.append(row['ticker']+': CIK 미확인');continue
  try:
   obs,files,name=sec(c,cik,row['id']);row['sec_collected_at']=now();row['sec_status']='COLLECTED_KEYWORD_ONLY';row['facts']={x['field']:x for x in obs};row['filings']=files;row['cik']=str(cik);row['risk_status']='공시 목록 확인 · 원계약 미확정'
   # Recent material funding/listing filings only; at most two primary documents per issuer.
   candidates=[f for f in files if f['form'] in ['8-K','6-K','S-1','S-1/A','S-3','S-3/A','F-1','F-3','424B3','424B5'] and f['filed']>=(dt.datetime.now(dt.timezone.utc)-dt.timedelta(days=90)).date().isoformat()][:2]
   for f in candidates:
    try:
     raw=c.get(f['source']).decode('utf-8',errors='replace');plain=re.sub(r'\s+',' ',re.sub('<[^>]+>',' ',raw))
     patterns={'ATM':r'at.the.market|equity distribution','RD/PIPE/ELOC':r'registered direct|private placement|equity line','워런트':r'warrant','전환사채':r'convertible (?:note|debt|debenture)','리셋/변동가격':r'floor price|reset|variable conversion|alternative conversion','재판매/락업':r'resale|selling stockholder|lock.up|rule 144','상장/병합':r'reverse (?:stock )?split|delist|minimum bid','현금 부족':r'going concern|substantial doubt'}
     for kind,pattern in patterns.items():
      m=re.search(pattern,plain,re.I)
      if m:row['risk_hits'].append({'type':kind,'excerpt':plain[max(0,m.start()-80):m.end()+170],'source':f['source'],'filed':f['filed'],'reviewed':False})
     f['review_status']='본문 문구 탐지 완료 · 계약 수동 검토 필요'
    except Exception as e:
     f['review_status']='본문 접근 실패: '+type(e).__name__;row['sec_status']='PARTIAL_DOCUMENT_FAILURE';errors.append(row['ticker']+': primary document '+type(e).__name__)
   if row['risk_hits']:row['risk_status']='미검토 위험 문구 '+str(len(row['risk_hits']))+'건 · 진입 보류'
  except Exception as e:row['sec_status']='COLLECTION_FAILED';row['sec_collected_at']=now();errors.append(row['ticker']+': '+type(e).__name__)
  row['sec_completed_at']=now();row['sec_sources']=c.log[log_start:]
  types={'ATM':'atm','워런트':'warrants','전환사채':'convertibles','재판매/락업':'resale','상장/병합':'listing'}
  for hit in row['risk_hits']:
   key=types.get(hit['type'])
   if key:row['risk_register'][key]['status']='KEYWORD_ONLY';row['risk_register'][key]['sources'].append(hit['source'])
  print('SEC',row['ticker'],row['risk_status'],flush=True)
 return errors

def main():
 p=argparse.ArgumentParser();p.add_argument('--limit',type=int,default=80,help='0=all eligible; default 80 balanced across four lanes');p.add_argument('--sec-limit',type=int,default=20);p.add_argument('--out',default='local-data/radar.json');a=p.parse_args()
 started=now();run_id=uuid.uuid4().hex;securities,eligible,chosen=discover(a.limit);print(f'목록 {len(securities)} / 시총·가격·거래량 조건 {len(eligible)} / 상세수집 {len(chosen)}',flush=True)
 rows=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  for i,r in enumerate(ex.map(details,chosen)):
   r['collection_run_id']=run_id;rows.append(r)
   if i%10==0:print('시세 수집',i+1,'/',len(chosen),flush=True)
 ok=sorted([r for r in rows if not r.get('error')],key=lambda r:(r['score'],r['rvol_daily'] or 0),reverse=True)
 sec_agent=os.getenv('SEC_USER_AGENT');sec_started=now()
 try:errors=sec_enrich(ok,a.sec_limit,sec_agent)
 except Exception as e:errors=['SEC 보완 실패: '+type(e).__name__]
 sec_status='SKIPPED_NO_IDENTITY' if not sec_agent else 'PARTIAL_OR_FAILED' if errors else 'COLLECTED_NOT_CONTRACT_REVIEWED'
 lane_counts={lane:sum(r.get('selection_lane')==lane for r in chosen) for lane in ['momentum','quiet_liquid','turnover_proxy','broad_sample','fill']}
 result={'schema_version':1,'kind':'real-current-radar','generated_at':now(),'collection_started_at':started,'run_id':run_id,'collector_version':'1.1.2-review','source_receipts':SOURCE_LOG,'collector_sha256':COLLECTOR_SHA256,'universe_count':len(securities),'eligible_count':len(eligible),'attempted_count':len(chosen),'success_count':len(ok),'not_evaluated_count':len(eligible)-len(chosen),'detail_failure_count':len(chosen)-len(ok),'selection_lanes':lane_counts,'selection_method':'4개 독립 사전필터: 변동률 / 낮은 변동률+유동성 / 거래회전 대리지표 / 종목코드 분산. 모두 현재 시점 자료. 예측력 미검증.','method':'현재 목록 → 시총 $3억 이하·주가 $0.1~20·거래량 10만주 이상 → 4개 경로로 상세수집(0=전수) → 고정 일봉 점수. 장중 급등 예측 아님.','daily_score_max':100,'full_market_realtime':False,'actual_backtest_completed':False,'sec_collection':{'run_id':run_id,'started_at':sec_started,'completed_at':now(),'status':sec_status,'attempt_limit':a.sec_limit,'errors':errors,'source':'SEC submissions/filings; no original contract verified'},'candidates':ok[:20],'additional_rows':ok[20:],'errors':[{'ticker':r['ticker'],'error':r['error']} for r in rows if r.get('error')]+errors,'limitations':['현재 다운로드한 일봉·시가총액으로 만든 관찰 목록. 실시간 진입 신호 아님.',f'{len(eligible)-len(chosen)}개 적격 종목 상세 미평가(요청 제한). {len(chosen)-len(ok)}개 수집 실패.','4개 사전필터는 시점별 예측력이 검증되지 않았으며, 표본 편향이 남습니다.','거래대금·Float·뉴스 20점 미확인. 점수는 상승확률 아님.','원계약 수동 검토·공매도/대차/FTD 확인 필요.','현재 자료로 과거 당시의 후보를 재구성하지 않음.']}
 write(a.out,result);print('저장 완료:',a.out,'후보',len(result['candidates']),flush=True)
if __name__=='__main__':main()
