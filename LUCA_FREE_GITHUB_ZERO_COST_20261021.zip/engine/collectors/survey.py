#!/usr/bin/env python3
"""100 lightweight quotes -> at most 25 qualifying detailed checks; append-only records."""
import argparse,concurrent.futures,datetime as dt,hashlib,json,pathlib,urllib.parse,uuid
from collect import Client,universe,now,write
from radar import get_json,SOURCE_LOG,ROOT,points
from dated_radar import metrics,crosscheck,SAFE
from session_calendar import latest_completed,close_at
RULES={'version':'survey-1','price_min':.1,'price_max':20,'volume_min':100000,'early_rvol':1.5,'early_change_min':0,'early_change_max':10,'breakout_rvol':2,'breakout_change_max':40,'drawdown_max':-.25,'stability_range_max':.10,'stability_change_max':5,'stability_rvol':1,'description':'사전 고정 관찰 가설. 결과에 맞춰 조정하지 않음. 실제 예측력 미검증.'}
def fingerprint(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def append_record(path,value):
 """Never replace a discovery or outcome record, even with an identical filename."""
 p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2)
 return str(p)
def lanes(m):
 b=m['daily'];p=m['price'];change=m['daily_change_pct'];rv=m['rvol_daily'];out=[]
 if not RULES['price_min']<=p<=RULES['price_max'] or m['volume']<RULES['volume_min']:return out
 if rv>=1.5 and 0<=change<=10 and p>m['sma5']:out.append('early_daily')
 if rv>=2 and 0<change<=40 and p>m['prior_high']:out.append('confirmed_daily')
 peak=max(x['h'] for x in b[-21:-1]);last=b[-3:]
 if p/peak-1<=-.25 and last[0]['l']<=last[1]['l']<=last[2]['l'] and max(x['h'] for x in last)/min(x['l'] for x in last)-1<=.10 and 0<=change<=5 and rv>=1:out.append('stabilizing_daily')
 return out
LABELS={'early_daily':'가격은 완만하게 오르고 거래가 증가','confirmed_daily':'거래 증가와 최근 5일 고점 돌파','stabilizing_daily':'최근 급락 뒤 3일간 저점이 더 낮아지지 않음'}
def shortlist(rows,limit):
 if not 1<=limit<=30:raise ValueError('상세 조사 상한은 1~30')
 out=[];seen=set();ordered=sorted(rows,key=lambda r:(-r.get('rvol_daily',0),r['ticker']))
 buckets={k:[r for r in ordered if k in r.get('discovery_lanes',[])] for k in ['early_daily','stabilizing_daily','confirmed_daily']}
 while len(out)<limit:
  before=len(out)
  for k,bucket in buckets.items():
   while bucket and bucket[0]['ticker'] in seen:bucket.pop(0)
   if bucket and len(out)<limit:
    r=bucket.pop(0);out.append(r);seen.add(r['ticker'])
  if len(out)==before:break
 return out

def light(seed,session):
 base={**seed,**SAFE,'dataKind':'real-current-radar','screening_eligible':False,'signal_status':'PRECHECK_ONLY','discovery_lanes':[],'market_cap':None,'microcap_status':'현재 시가총액 미확인 · 과거 소형주 명부 표본'}
 try:
  url='https://query1.finance.yahoo.com/v8/finance/chart/'+urllib.parse.quote(seed['ticker'],safe='')+'?range=3mo&interval=1d&events=splits'
  raw=get_json(url);retrieved=now()
  if raw['chart']['result'][0]['meta'].get('symbol')!=seed['ticker']:raise ValueError('Yahoo 종목 불일치')
  m=metrics(raw,session);found=lanes(m)
  return {**base,**m,**points(m,{}),'yahoo_url':url,'yahoo_retrieved_at':retrieved,'discovery_lanes':found,'light_status':'QUALIFIES' if found else 'NO_CONDITION','light_reason':'; '.join(LABELS[x] for x in found) if found else '사전 고정 3개 관찰 경로 모두 조건 불충족'}
 except Exception as e:return {**base,'light_status':'DATA_BLOCKED','error':type(e).__name__+': '+str(e)[:140],'light_reason':'거래일·종목·일봉·병합 단위 확인 실패'}
def detailed(r,session):
 base={**r,**SAFE,'survey_rule_version':RULES['version'],'id':r['exchange']+':'+r['ticker']+':'+session,'facts':{},'filings':[],'risk_hits':[],'sec_status':'NOT_REQUESTED','risk_status':'SEC 원계약·상장유지 미확인 · 매수 차단','risk_register':{k:{'status':'UNKNOWN','reviewed':False,'sources':[]} for k in ['float','warrants','atm','convertibles','resale','listing','short_interest','ctb']},'source':'https://finance.yahoo.com/quote/'+r['ticker']+'/history/','source_screener':'https://www.nasdaq.com/market-activity/stocks/'+r['ticker'].lower()+'/historical','against':['현재 시총·Float·SEC 계약·상장유지·공매도 미확인','일봉 관찰이며 장중 진입 신호 아님'],'reasons':[r['light_reason'],f"거래량 {r['rvol_daily']:.2f}배 · 같은 일봉 등락 {r['daily_change_pct']:.2f}%"],'selection_lane':'date_unverified','date_verified':False,'screening_eligible':False,'signal_status':'DATA_BLOCKED'}
 try:
  url='https://api.nasdaq.com/api/quote/'+urllib.parse.quote(r['ticker'],safe='')+'/historical?'+urllib.parse.urlencode({'assetclass':'stocks','limit':5,'fromdate':(dt.date.fromisoformat(session)-dt.timedelta(days=8)).isoformat(),'todate':session})
  raw=get_json(url);retrieved=now();base['nasdaq_url']=url;base['nasdaq_retrieved_at']=retrieved
  e=crosscheck(raw,r['ticker'],session,r)
  if latest_completed(dt.datetime.now(dt.timezone.utc))!=session:raise ValueError('조사 중 다음 거래일 마감: 이전 일봉 후보 차단')
  e.update({'method':'yahoo-nasdaq-historical-v1','yahoo_session':session,'yahoo_retrieved_at':r['yahoo_retrieved_at'],'nasdaq_retrieved_at':retrieved,'yahoo_url':r['yahoo_url'],'nasdaq_url':url,'regular_close_at':close_at(dt.date.fromisoformat(session)).isoformat()})
  return {**base,'dated_evidence':e,'quote_collected_at':retrieved,'date_verified':True,'screening_eligible':True,'selection_lane':(r['discovery_lanes'] or ['reference_activity'])[0],'signal_status':'OBSERVATION_ONLY','selected_at':now(),'stage':'실제 일봉 관찰 · 매수 불가'}
 except Exception as e:return {**base,'error':type(e).__name__+': '+str(e)[:140]}

def run_survey(count,detail_limit,out):
 if not 80<=count<=120:raise ValueError('1차 조사는 80~120개만 허용')
 if not 20<=detail_limit<=30:raise ValueError('상세 상한은 20~30개만 허용')
 out=pathlib.Path(out);started=now();session=latest_completed(dt.datetime.now(dt.timezone.utc));run_id=started.replace(':','-')+'-'+uuid.uuid4().hex[:8]
 rules_doc={'fixed_before_collection_at':started,'rules':RULES,'rules_sha256':fingerprint(RULES),'collector_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
 append_record(out/'runs'/run_id/'rules.json',rules_doc)
 client=Client();securities=universe(client);listed={s['listings'][0]['ticker']:s for s in securities}
 seed=json.loads((ROOT/'config/survey-seed-registry.json').read_text());pool=[s for s in seed['rows'] if s['ticker'] in listed]
 chosen=sorted(pool,key=lambda r:hashlib.sha256((session+':survey-1:'+r['ticker']).encode()).hexdigest())[:count]
 if len(chosen)<count:raise ValueError('조사 모집단 부족: 표본 임의 보충하지 않음')
 chosen=[{**r,'exchange':listed[r['ticker']]['listings'][0]['exchange']} for r in chosen];tickers={r['ticker'] for r in chosen}
 population={'current_directory_count':len(listed),'historical_seed_count':len(seed['rows']),'accessible_seed_count':len(pool),'light_limit':count,'detail_limit':detail_limit,'seed_source_sha256':seed['source_sha256'],'seed_caveat':seed['purpose'],'selection_method':'완료 거래일+survey-1+종목코드 SHA256 오름차순 표본; 현재 수익률에 따른 표본 선택 아님','sample_tickers':sorted(tickers),'not_sampled_tickers':sorted(r['ticker'] for r in pool if r['ticker'] not in tickers),'not_listed_tickers':sorted(r['ticker'] for r in seed['rows'] if r['ticker'] not in listed),'other_current_listing_count':len(listed)-len(pool)}
 append_record(out/'runs'/run_id/'population.json',population)
 light_rows=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
  for i,r in enumerate(ex.map(lambda s:light(s,session),chosen)):
   light_rows.append(r)
   if (i+1)%10==0:print('가벼운 조사',i+1,'/',count,flush=True)
   append_record(out/'runs'/run_id/'light'/f"{i:03d}.json",r)
 short=shortlist(light_rows,detail_limit);details=[]
 for r in short:
  item=detailed(r,session);details.append(item);print('상세 대조',r['ticker'],item['signal_status'],item.get('error',''),flush=True)
 now_at=now();final_session=latest_completed(dt.datetime.fromisoformat(now_at.replace('Z','+00:00')))
 if final_session!=session:
  for r in details:r.update(date_verified=False,screening_eligible=False,signal_status='DATA_BLOCKED',error='선정 완료 전에 다음 장 마감: 이전 일봉 제외')
 candidates=[r for r in details if r['screening_eligible']];errors=[{'ticker':r['ticker'],'error':r['error']} for r in light_rows+details if r.get('error')]
 result={**SAFE,'schema_version':1,'kind':'real-current-radar','dataKind':'real-current-radar','collector_version':'survey-1','generated_at':now_at,'collection_started_at':started,'run_id':run_id,'session':session,'selection_known_at':now_at,'rules_snapshot':rules_doc,'population':population,'universe_count':len(listed),'eligible_count':None,'attempted_count':count,'success_count':sum(r['light_status']!='DATA_BLOCKED' for r in light_rows),'not_evaluated_count':len(pool)-count,'detail_failure_count':len(details)-len(candidates),'light_qualified_count':sum(bool(r['discovery_lanes']) for r in light_rows),'detail_attempted_count':len(details),'detail_limit':detail_limit,'screening_candidate_count':len(candidates),'candidates':candidates[:20],'additional_rows':candidates[20:],'rejected_details':[r for r in details if not r['screening_eligible']],'light_results':light_rows,'source_receipts':SOURCE_LOG+client.log,'errors':errors,'schedule_status':'중지 · 수동 실행 기록','actual_backtest_completed':False,'full_market_realtime':False,'method':f'{count}개 완료 일봉 1차 조사 → 조건 충족만 최대 {detail_limit}개 다른 출처 대조 → 원본 고정 기록','selection_method':'거래량 증가·고점 돌파·급락 뒤 저점 안정화. 결과를 본 뒤 조건을 바꾸지 않음.','limitations':['현재 시총·SEC 계약·Float·상장유지·공매도 미확인. 실제 매수 차단.','과거 소형주 명부의 날짜별 표본이며 미국시장 전수조사 아님.','실제 매매 수익률 및 급등 적중률 NOT_VALIDATED.','자동 갱신은 중지. 수동 조사 시 날짜별 파일 추가.']}
 selected_path=out/'selections'/session/(run_id+'.json');append_record(selected_path,result)
 receipts=out/'runs'/run_id/'source-raw';receipts.mkdir(exist_ok=True)
 for rec in result['source_receipts']:
  raw=(ROOT/'cache'/(rec['sha256']+'.raw')).read_bytes()
  if hashlib.sha256(raw).hexdigest()!=rec['sha256']:raise ValueError('원본 지문 불일치')
  (receipts/(rec['sha256']+'.raw')).write_bytes(raw)
 manifest={'selection_file':str(selected_path.relative_to(out)),'selection_sha256':hashlib.sha256(selected_path.read_bytes()).hexdigest(),'session':session,'selected_at':now_at,'candidate_count':len(candidates)}
 append_record(out/'runs'/run_id/'manifest.json',manifest)
 # A zero-candidate successful run is valid; total quote failure preserves last normal view.
 if result['success_count']:
  tmp=out/'latest.tmp';write(tmp,result);tmp.replace(out/'latest.json')
 print(json.dumps({'population':population['accessible_seed_count'],'light':count,'light_valid':result['success_count'],'qualified':result['light_qualified_count'],'detailed':len(details),'candidates':len(candidates),'selection_file':str(selected_path),'selection_sha256':manifest['selection_sha256']},ensure_ascii=False),flush=True)
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--light-limit',type=int,default=100);p.add_argument('--detail-limit',type=int,default=25);p.add_argument('--out',default='local-data/survey-history');a=p.parse_args();run_survey(a.light_limit,a.detail_limit,a.out)
