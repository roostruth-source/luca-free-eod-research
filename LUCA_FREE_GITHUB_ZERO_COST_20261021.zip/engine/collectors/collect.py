#!/usr/bin/env python3
"""Public-data collectors. Python 3.10+, standard library only; no trading API calls."""
import argparse, csv, datetime as dt, hashlib, io, json, os, pathlib, re, time, urllib.parse, urllib.request
from zoneinfo import ZoneInfo
UTC=dt.timezone.utc
ROOT=pathlib.Path(__file__).resolve().parents[1]
def now(): return dt.datetime.now(UTC).isoformat().replace('+00:00','Z')
def stamp(s): return dt.datetime.fromisoformat(s.replace('Z','+00:00'))
def write(path,data):
 p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
class Client:
 def __init__(self,agent=None): self.agent=agent;self.last=0;self.log=[]
 def get(self,url,headers=None):
  if 'sec.gov' in urllib.parse.urlparse(url).netloc:
   if not self.agent or '@' not in self.agent: raise ValueError('SEC_USER_AGENT 환경변수에 앱 이름과 실제 연락 이메일을 입력하세요.')
   time.sleep(max(0,0.25-(time.monotonic()-self.last)))
  h={'User-Agent':self.agent or 'LucaMicrocap/1.0 public-data-research','Accept':'application/json,text/plain,*/*'};h.update(headers or {})
  self.last=time.monotonic()
  with urllib.request.urlopen(urllib.request.Request(url,headers=h),timeout=25) as r: raw=r.read()
  # API keys must never enter logs. HTTP auth is passed only through request headers.
  clean=urllib.parse.urlunsplit((*urllib.parse.urlsplit(url)[:3],'',''))
  self.log.append({'url':clean,'retrieved_at':now(),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
  cache=ROOT/'cache';cache.mkdir(exist_ok=True);(cache/(hashlib.sha256(raw).hexdigest()+'.raw')).write_bytes(raw)
  return raw
 def json(self,url,headers=None): return json.loads(self.get(url,headers))
def empty(): return {'schema_version':1,'meta':{'kind':'real','created_at':now(),'point_in_time_universe':False,'includes_delisted':False,'original_vintages':False,'corporate_actions_complete':False,'full_market':False,'limitations':[]},'securities':[],'bars':[],'observations':[],'filings':[],'collection_log':[]}
def universe(client):
 at=now();out=[]
 for filename in ['nasdaqlisted.txt','otherlisted.txt']:
  url='https://www.nasdaqtrader.com/dynamic/symdir/'+filename
  raw=client.get(url).decode('utf-8-sig');rows=csv.DictReader(io.StringIO(raw),delimiter='|')
  for r in rows:
   symbol=r.get('Symbol') or r.get('ACT Symbol')
   if not symbol or symbol.startswith('File Creation') or r.get('Test Issue')!='N' or r.get('ETF')!='N':continue
   exchange='XNAS' if filename=='nasdaqlisted.txt' else {'N':'XNYS','A':'XASE'}.get(r.get('Exchange'))
   if not exchange:continue
   name=r.get('Security Name','')
   # The directory lacks an authoritative security-type field. Keep only explicitly named common/ordinary/ADR issues.
   if re.search(r'warrant|\bunits?\b|preferred|depositary shares.*preferred|notes due|rights',name,re.I):continue
   if not re.search(r'common|ordinary|american depositary|american depository|\bADS\b',name,re.I):continue
   kind='ADRC' if re.search(r'depositary|depository|\bADS\b',name,re.I) else 'CS'
   out.append({'id':exchange+':'+symbol+':'+at[:10],'name':name,'listings':[{'ticker':symbol,'exchange':exchange,'type':kind,'start':at,'end':None,'known_at':at}],'directory_status':r.get('Financial Status','미확인')})
 return out

def sec(client,cik,id,basis='unverified'):
 cik=str(cik).zfill(10);sub=client.json(f'https://data.sec.gov/submissions/CIK{cik}.json');recent=sub['filings']['recent'];filings=[]
 for i,acc in enumerate(recent['accessionNumber']):
  form=recent['form'][i]
  if form not in ['8-K','6-K','S-1','S-1/A','S-3','S-3/A','F-1','F-1/A','F-3','F-3/A','424B3','424B5','EFFECT','10-Q','10-K','20-F','4','SC 13D','SC 13D/A','SC 13G','SC 13G/A']:continue
  doc=recent['primaryDocument'][i];url=f'https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace("-","")}/{doc}'
  filings.append({'id':id,'form':form,'accepted_at':recent.get('acceptanceDateTime',['']*len(recent['form']))[i],'filed':recent['filingDate'][i],'accession':acc,'source':url,'review_status':'본문 미검토'})
  if len(filings)>=40:break
 facts=client.json(f'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json');out=[];at=now()
 mappings=[('os','dei','EntityCommonStockSharesOutstanding','shares'),('cash','us-gaap','CashAndCashEquivalentsAtCarryingValue','USD')]
 for field,ns,tag,unit in mappings:
  rows=facts.get('facts',{}).get(ns,{}).get(tag,{}).get('units',{}).get(unit,[])
  rows=[r for r in rows if r.get('end','')<=at[:10] and r.get('filed','')<=at[:10] and r.get('val',-1)>=0]
  if not rows:continue
  row=max(rows,key=lambda r:(r.get('end',''),r.get('filed','')))
  acc=row.get('accn','');source=f'https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace("-","")}/{acc}-index.html'
  out.append({'id':id,'field':field,'value':row['val'],'unit':unit,'basis':basis,'effective_at':row['end']+'T23:59:59Z','known_at':at,'source':source,'confidence':'XBRL 원자료 · 현 주식 단위 별도 확인','notes':'수집 시각 이후만 사용. OS는 공시 기준 주식수이며 현재 실제 OS/ADR 환산은 별도 검토.'})
 # No inference of float from public float dollar value; no fabricated debt totals/runway.
 return out,filings,sub.get('name','')

def alpaca(client,securities,start,end,feed):
 key=os.environ.get('APCA_API_KEY_ID');secret=os.environ.get('APCA_API_SECRET_KEY')
 if not key or not secret:raise ValueError('Alpaca 데이터 키 필요: APCA_API_KEY_ID / APCA_API_SECRET_KEY. 주문 권한은 사용하지 않습니다.')
 headers={'APCA-API-KEY-ID':key,'APCA-API-SECRET-KEY':secret};bars=[];at=now();ny=ZoneInfo('America/New_York')
 for s in securities:
  symbol=s['listings'][-1]['ticker'];page=None
  while True:
   q={'symbols':symbol,'timeframe':'1Min','start':start,'end':end,'adjustment':'raw','feed':feed,'limit':10000,'sort':'asc'}
   if page:q['page_token']=page
   j=client.json('https://data.alpaca.markets/v2/stocks/bars?'+urllib.parse.urlencode(q),headers)
   for b in j.get('bars',{}).get(symbol,[]):
    begin=stamp(b['t']);finish=begin+dt.timedelta(minutes=1);local=begin.astimezone(ny);minute=local.hour*60+local.minute-570
    if minute<0 or minute>=390 or finish>stamp(at):continue
    bars.append({'id':s['id'],'start':begin.isoformat(),'end':finish.isoformat(),'known_at':at,'session':local.date().isoformat(),'minute_of_session':minute,'timeframe':'minute','open':b['o'],'high':b['h'],'low':b['l'],'close':b['c'],'volume':b['v'],'vwap':b.get('vw'),'basis':'current-raw','regular':True,'source':'Alpaca '+feed,'notes':'현재 내려받은 수정 가능 자료. 과거 당시 버전으로 소급하지 않음.'})
   page=j.get('next_page_token')
   if not page:break
 # Latest historical bars do not carry NBBO: spread remains unknown.
 return bars

def finra(client,date):
 raw=client.get('https://cdn.finra.org/equity/regsho/daily/CNMSshvol'+date.replace('-','')+'.txt').decode()
 return [r for r in csv.DictReader(io.StringIO(raw),delimiter='|') if r.get('Symbol') and r.get('TotalVolume','').isdigit()]

def market_coverage(feed,selected,all_securities,start,end):
 # SIP is a data-feed label, not proof of all-symbol / all-date coverage.
 # Never set full_market before independent symbol/date/bar reconciliation.
 return {'market_feed':feed,'full_market':False,'market_coverage':{
  'requested_symbols':len(selected),'universe_symbols':len(all_securities),
  'requested_start':start,'requested_end':end,
  'coverage_verified':False,'complete_sessions_verified':False,
  'note':'SIP feed alone does not establish full market or point-in-time coverage.'}}

def main():
 p=argparse.ArgumentParser(description='루카 V1 무료 공개자료 / 선택형 Alpaca 수집')
 sp=p.add_subparsers(dest='cmd',required=True)
 u=sp.add_parser('universe');u.add_argument('--out',default='local-data/universe.json')
 s=sp.add_parser('sec');s.add_argument('--cik',required=True);s.add_argument('--ticker',required=True);s.add_argument('--exchange',default='XNAS',choices=['XNAS','XNYS','XASE']);s.add_argument('--out',default='local-data/sec.json');s.add_argument('--input',help='기존 JSON에 같은 ticker의 공시와 관측값을 추가');s.add_argument('--documents',type=int,default=0,help='우선 공시 본문 탐지 개수 (최대 10)')
 a=sp.add_parser('market');a.add_argument('--input',required=True);a.add_argument('--symbols',required=True,help='쉼표로 나눈 종목 또는 ALL. ALL은 많은 요청 발생');a.add_argument('--start',required=True);a.add_argument('--end',required=True);a.add_argument('--feed',choices=['iex','sip'],default='iex');a.add_argument('--out',default='local-data/market.json')
 f=sp.add_parser('finra');f.add_argument('--date',required=True);f.add_argument('--input',required=True);f.add_argument('--out',default='local-data/finra.json')
 r=sp.add_parser('filing');r.add_argument('--url',required=True);r.add_argument('--out',default='local-data/filing.txt')
 args=p.parse_args();client=Client(os.environ.get('SEC_USER_AGENT'))
 try:
  if args.cmd=='universe':
   d=empty();d['securities']=universe(client);d['meta']['limitations']=['현재 상장 목록만 포함. 과거 유니버스로 사용 금지. 이름 기반 보통주/ADR 분류는 추가 점검 필요.'];d['collection_log']=client.log;write(args.out,d);print(f'{len(d["securities"])}개 종목 목록 저장. 가격·시총 미수집: 아직 후보 선정 결과가 아닙니다.')
  elif args.cmd=='sec':
   d=json.loads(pathlib.Path(args.input).read_text()) if args.input else empty();at=now();matches=[x for x in d['securities'] if x['listings'][-1]['ticker']==args.ticker];id=matches[0]['id'] if matches else 'CIK:'+str(int(args.cik));observations,filings,name=sec(client,args.cik,id)
   
   if not matches:d['securities'].append({'id':id,'name':name,'listings':[{'ticker':args.ticker,'exchange':args.exchange,'type':'CS','start':at,'known_at':at,'end':None}]})
   d['observations']+=observations;d.setdefault('filings',[]).extend(filings)
   for filing in filings[:max(0,min(args.documents,10))]:
    try:
     text=client.get(filing['source']).decode('utf-8',errors='replace');plain=re.sub('<[^>]+>',' ',text)
     patterns={'dilution':r'at.the.market|registered direct|private placement|equity line|warrant|convertible|floor price|reset','supply':r'resale|selling stockholder|lock.up|rule 144','listing_risk':r'reverse (?:stock )?split|delist|minimum bid','cash_risk':r'going concern|substantial doubt'}
     for field,pattern in patterns.items():
      m=re.search(pattern,plain,re.I)
      if m:d['observations'].append({'id':id,'field':field,'value':{'reviewed':False,'review_required':True,'severity':None,'summary':'미검토 위험 문구: '+re.sub(r'\s+',' ',plain[max(0,m.start()-80):m.end()+180])},'effective_at':filing['accepted_at'] or at,'known_at':now(),'source':filing['source']})
     filing['review_status']='위험 문구 자동 탐지 · 원계약 미검토'
    except Exception as e:filing['review_status']='본문 수집 실패: '+type(e).__name__
   d['collection_log']+=client.log;write(args.out,d);print(f'SEC 관측값 {len(observations)}개 / 공시 링크 {len(filings)}개. 거래소·주식종류는 입력값이며 원문 확인 필요.')
  elif args.cmd=='market':
   d=json.loads(pathlib.Path(args.input).read_text());symbols=args.symbols.split(',');selected=[s for s in d['securities'] if args.symbols=='ALL' or s['listings'][-1]['ticker'] in symbols]
   if not selected:raise ValueError('입력 파일에서 종목을 찾지 못했습니다.')
   d['bars']=alpaca(client,selected,args.start,args.end,args.feed);d['collection_log']+=client.log;d['meta'].update(market_coverage(args.feed,selected,d['securities'],args.start,args.end));d['meta']['limitations'].append('원본 과거 버전·기업행동·호가 미확인. IEX는 시장 전체 거래량이 아님.');write(args.out,d);print(f'{len(d["bars"])}개 분봉 저장. 시점 미확인 값은 과거 백테스트에서 제외됩니다.')
  elif args.cmd=='finra':
   d=json.loads(pathlib.Path(args.input).read_text());rows=finra(client,args.date);by={r['Symbol']:r for r in rows};at=now()
   for s in d['securities']:
    r=by.get(s['listings'][-1]['ticker']);total=int(r['TotalVolume']) if r else 0
    if total:d['observations'].append({'id':s['id'],'field':'short_volume','value':int(r['ShortVolume'])/total,'effective_at':args.date+'T23:59:59Z','known_at':at,'source':'https://www.finra.org/finra-data/browse-catalog/short-sale-volume','notes':'FINRA 보고 범위만 포함. 공매도 잔고 비율이 아님.'})
   d['collection_log']+=client.log;write(args.out,d);print('FINRA 거래 비중 추가 완료. 과거 공개 시각을 추정하지 않습니다.')
  else:
   u=urllib.parse.urlparse(args.url)
   if u.scheme!='https' or u.hostname not in ['www.sec.gov','sec.gov'] or not u.path.startswith('/Archives/edgar/data/'):raise ValueError('SEC Archives 원문 URL만 허용됩니다.')
   from html.parser import HTMLParser
   class Extract(HTMLParser):
    def __init__(self):super().__init__();self.parts=[]
    def handle_data(self,data):self.parts.append(data)
   parser=Extract();parser.feed(client.get(args.url).decode('utf-8',errors='replace'));out=pathlib.Path(args.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(' '.join(parser.parts),encoding='utf-8');write(str(out)+'.provenance.json',client.log);print('공시 본문 저장. CLI risks 또는 대시보드에서 문구 탐지 가능.')
 except Exception as e:
  # Never dump headers or credentials, and never silently replace a failed feed with mock data.
  print('수집 실패:',type(e).__name__,str(e)[:250]);raise SystemExit(1)
if __name__=='__main__':main()
