#!/usr/bin/env python3
"""Work-independent standalone launcher; creates isolated one-shot workspace.
No network unless explicit 'collect' command; never touches operational site, Git, or scheduler.
"""
import argparse, datetime as dt, hashlib, json, os, pathlib, shutil, socket, subprocess, sys, uuid
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=ROOT/'local-data/manual-refresh-research/baseline'
BASE=ROOT/'local-data/standalone-workspaces'
DOMAINS=('query1.finance.yahoo.com','www.nasdaqtrader.com')
def workspace_path(value):
 p=pathlib.Path(value).resolve()
 if not p.is_relative_to(BASE.resolve()) or p==BASE.resolve():raise ValueError('standalone-workspaces 하위 준비된 폴더만 허용')
 meta=p/'workspace.json'
 if not meta.is_file():raise ValueError('prepare 명령으로 생성된 폴더만 실행 가능')
 info=json.loads(meta.read_text(encoding='utf-8'))
 if info.get('type')!='LUCA_ISOLATED_RESEARCH' or str(p)!=info.get('home'):raise ValueError('연구판 식별 검증 실패')
 return p
def child_env(home):return {**os.environ,'LUCA_RESEARCH_HOME':str(home),'PYTHONDONTWRITEBYTECODE':'1'}
def execute(home,option):
 result=subprocess.run([sys.executable,str(ROOT/'research/refresh.py'),option],cwd=ROOT,env=child_env(home),capture_output=True,text=True,timeout=90)
 log=home/'local-rebuild.log';log.write_text('exit='+str(result.returncode)+'\n'+result.stdout+'\n'+result.stderr,encoding='utf-8')
 return result

def prepare():
 BASE.mkdir(parents=True,exist_ok=True)
 if not SOURCE.is_dir():raise ValueError('원본 검증 자료 baseline 누락')
 name='luca-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
 home=BASE/name;home.mkdir(mode=0o700)
 shutil.copytree(SOURCE,home/'baseline')
 manifest=list((home/'baseline/runs').glob('*/manifest.json'))
 if len(manifest)!=1:raise ValueError('기준 자료 manifest이 정확히 하나여야 함')
 state={'history':'baseline','manifest':str(manifest[0].relative_to(home/'baseline')),'status':'BASELINE_ONLY','attempts':[]}
 (home/'state.json').write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
 (home/'workspace.json').write_text(json.dumps({'type':'LUCA_ISOLATED_RESEARCH','home':str(home),'created_at':dt.datetime.now(dt.timezone.utc).isoformat(),'market_collect_count':0},ensure_ascii=False,indent=2),encoding='utf-8')
 result=execute(home,'--rebuild')
 if result.returncode:raise RuntimeError('초기 원본/HTML 검증 실패: '+result.stderr[-300:])
 print('생성 완료:',home,'\n오프라인 HTML:',home/'exports/LUCA_REFRESH_IPHONE.html')
 return home

def preflight():
 problems=[]
 for host in DOMAINS:
  try:socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)
  except OSError as e:problems.append(host+': '+type(e).__name__)
 return problems

def collect(home):
 marker=home/'stability-once.json'
 if marker.exists():raise ValueError('이미 수동 1회 실행됨. 자동 재시도 금지. 새 준비판 필요')
 if (home/'running.lock').exists():raise ValueError('미종료 잠금 발견. 이전 실행 기록부터 확인할 것')
 issues=preflight()
 if issues:
  (home/'preflight-failure.json').write_text(json.dumps({'status':'PRECHECK_BLOCKED','source':'DNS','issues':issues,'market_collection_count':0},ensure_ascii=False,indent=2),encoding='utf-8')
  print('시장 수집 시작하지 않음: DNS 접속 조건 실패',*issues,sep='\n',file=sys.stderr)
  return 2
 print('실제 시장 요청을 수동 1회 시작합니다. 자동 재시도/주문/배포 없음.',flush=True)
 p=subprocess.run([sys.executable,'-u',str(ROOT/'research/stability_once.py')],cwd=ROOT,env=child_env(home),timeout=1300)
 result=home/'supervisor-result.json'
 if result.exists():print(result.read_text(encoding='utf-8')[:2500])
 print('HTML:',home/'exports/LUCA_REFRESH_IPHONE.html')
 return p.returncode

def inspect(home):
 state=json.loads((home/'state.json').read_text(encoding='utf-8'))
 print('자료 경로:',home)
 print('선정 원본:',state.get('history'),'  신규 완료:',state.get('last_attempt',{}).get('status','없음'))
 if (home/'supervisor-result.json').is_file():
  result=json.loads((home/'supervisor-result.json').read_text(encoding='utf-8'))
  print('감독기:',result.get('status'),'성공:',result.get('successful_refresh',False),'종료 코드:',result.get('exit_code'))
 html=home/'exports/LUCA_REFRESH_IPHONE.html'
 print('아이폰 HTML:',html if html.exists() else '없음')
 print('실제 매수: 차단 / 성과: NOT_VALIDATED')

def main():
 p=argparse.ArgumentParser(description='루카 수동 조사 · 독립 복사본. Work 불필요, 자동매매 없음.')
 sub=p.add_subparsers(dest='action',required=True)
 sub.add_parser('prepare',help='인터넷 없이 새 독립 연구 복사본+과거 아이폰 화면 생성')
 for action in ['collect','rebuild','inspect']:
  a=sub.add_parser(action);a.add_argument('--workspace',required=True,help='prepare 결과의 절대 경로')
 a=p.parse_args()
 try:
  if a.action=='prepare':prepare();return 0
  home=workspace_path(a.workspace)
  if a.action=='collect':return collect(home)
  if a.action=='rebuild':
   r=execute(home,'--rebuild');print('재생성',r.returncode,home/'exports/LUCA_REFRESH_IPHONE.html');return r.returncode
  inspect(home);return 0
 except (OSError,ValueError,RuntimeError,subprocess.TimeoutExpired) as ex:
  print('안전 중단:',type(ex).__name__,str(ex)[:400],file=sys.stderr);return 1
if __name__=='__main__':sys.exit(main())
