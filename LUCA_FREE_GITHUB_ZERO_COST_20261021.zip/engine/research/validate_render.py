"""Read-only rendering gate. Never collects or writes source evidence."""
import json,sys,pathlib
from refresh import verify,completion_check
try:
 p=json.load(sys.stdin);loc=p['evidence_location'];h=pathlib.Path(loc['history']);m=pathlib.Path(loc['manifest'])
 d,proof=verify(h,m,require_current=False)
 completion=completion_check(h,m,p['status'])
 if json.dumps(completion,sort_keys=True)!=json.dumps(p.get('completion'),sort_keys=True):raise ValueError('입력 완료 정보와 디스크 완료 정보 전체 불일치')
 if d!=p['data'] or proof!=p['proof']:raise ValueError('표시 자료와 디스크 검증 결과 불일치')
 print(json.dumps({'verified':True}))
except Exception:
 print(json.dumps({'verified':False}));sys.exit(1)
