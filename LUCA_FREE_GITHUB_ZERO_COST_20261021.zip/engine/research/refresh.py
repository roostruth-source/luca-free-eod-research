"""Isolated manual research: unchanged collector -> offline proof -> HTML. No orders/sites."""
import http.client
import argparse, contextlib, csv, datetime as dt, hashlib, io, json, math, os, pathlib, re, subprocess, sys, threading, time, urllib.request, urllib.error, uuid, xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'collectors'))
import movement, radar
from collect import now, Client
from dated_radar import metrics, crosscheck
from session_calendar import close_at, latest_completed, next_close, NY
HOME=pathlib.Path(os.environ['LUCA_RESEARCH_HOME']).expanduser().resolve() if os.environ.get('LUCA_RESEARCH_HOME') else ROOT/'local-data/manual-refresh-research'
def sha(b):return hashlib.sha256(b).hexdigest()
def stamp(v):
 t=dt.datetime.fromisoformat(v.replace('Z','+00:00'))
 if t.tzinfo is None:raise ValueError('시간대 없는 날짜')
 return t
def save(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
def atomic(p,d):
 tmp=p.with_suffix('.tmp');save(tmp,d);tmp.replace(p)
def inside(root,relative):
 p=(root/relative).resolve()
 if not p.is_relative_to(root.resolve()):raise ValueError('연구 기록 밖 경로 차단')
 return p
def process_identity(pid):
 """Best-effort Linux process identity: PID alone is never an ownership proof."""
 try:
  stat=(pathlib.Path('/proc')/str(pid)/'stat').read_text()
  # The second field (comm) may contain spaces or parentheses.
  fields=stat[stat.rfind(')')+2:].split()
  ticks=int(fields[19])  # field 22 (starttime), with fields starting at 3
  boot=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()
  return {'pid_start_ticks':ticks,'boot_id':boot}
 except (OSError,ValueError,IndexError):return None

def safe_flags(d):
 return all(d.get(k) is False for k in ['entry_allowed','entryAllowed','reviewEvidenceVerified','simulationEligible','simulationOnly','precision_candidate_allowed','performance_verified']) and d.get('validationStatus')=='NOT_VALIDATED' and d.get('validation_status')=='NOT_VALIDATED'
def verify(history,manifest_path,at=None,require_current=True):
 """Recalculate saved evidence; never trusts flags/receipt strings alone."""
 at=at or dt.datetime.now(dt.timezone.utc);history=pathlib.Path(history).resolve();mp=pathlib.Path(manifest_path).resolve()
 if not mp.is_relative_to(history):raise ValueError('manifest 경로 오류')
 m=json.loads(mp.read_text());p=inside(history,m['selection_file']);b=p.read_bytes();selection_digest=sha(b)
 if sha(b)!=m['selection_sha256']:raise ValueError('선정 원문 SHA256 불일치')
 d=json.loads(b);session=d['session'];selected=stamp(d['selection_known_at']);started=stamp(d['collection_started_at']);close=close_at(dt.date.fromisoformat(session))
 if not close or not close<=started<=selected<=at or latest_completed(selected)!=session:raise ValueError('미래/미완료/잘못된 거래일')
 if require_current and latest_completed(at)!=session:raise ValueError('최신 완료 거래일 아님')
 if d.get('kind')!='real-current-radar' or d.get('research_track')!='partial-coverage-v1' or d.get('counts_as_frozen_five_session') is not False or not safe_flags(d):raise ValueError('연구 종류/안전 차단값 불일치')
 if not 1<=d['attempted_count']<=100 or not 0<=d['detail_attempted_count']<=25 or d['requested_light_count']!=100 or d['detail_limit']!=25:raise ValueError('100/25 상한 또는 조사 수 오류')
 rule=d['rules_snapshot']
 if rule['collector_sha256']!=sha((ROOT/'collectors/movement.py').read_bytes()):raise ValueError('수집기 고정 코드 불일치')
 for f,h in rule['source_hashes'].items():
  if not f.startswith('collectors/') or sha(inside(ROOT,f).read_bytes())!=h:raise ValueError('고정 기준 파일 불일치')
 if rule['formal_rules_sha256']!=movement.fingerprint(movement.RULES) or rule['reference_rules_sha256']!=movement.fingerprint(movement.REFERENCE_RULES):raise ValueError('선정 기준 불일치')
 recs={};raw={}
 for r in d['source_receipts']:
  h=r['sha256']
  if not re.fullmatch('[0-9a-f]{64}',h) or r['url'] in recs:raise ValueError('출처 영수증 중복/형식 오류')
  t=stamp(r['retrieved_at'])
  if not started<=t<=selected:raise ValueError('원본 수신 시각 범위 오류')
  value=(mp.parent/'source-raw'/(h+'.raw')).read_bytes()
  if sha(value)!=h or len(value)!=r['bytes']:raise ValueError('원본 영수증 해시/크기 불일치')
  recs[r['url']]=r;raw[r['url']]=value
 def chart(r):
  url=r['yahoo_url'];j=json.loads(raw[url]);rec=recs[url]
  if url!='https://query1.finance.yahoo.com/v8/finance/chart/'+r['ticker']+'?range=3mo&interval=1d&events=splits' or j['chart']['result'][0]['meta']['symbol']!=r['ticker']:raise ValueError('출처 종목/URL 불일치')
  calc=metrics(j,session)
  for k in ['daily','price','volume','session','rvol_daily','sma5','prior_high','daily_change_pct','quote_at']:
   if r.get(k)!=calc[k]:raise ValueError('원본 재계산 불일치: '+k)
  q=stamp(r['quote_at']);received=stamp(r['yahoo_retrieved_at'])
  if not close<=q<=close+dt.timedelta(minutes=15) or not q<=stamp(rec['retrieved_at'])<=received<=selected:raise ValueError('시세/마감/수신 시각 불일치')
  if q.astimezone(NY).date().isoformat()!=session:raise ValueError('시세 거래일 불일치')
  return calc
 light=d['light_results'];chosen=d['population']['chosen']
 if len(light)!=d['attempted_count'] or len({r['ticker'] for r in light})!=len(light) or {r['ticker'] for r in light}!={r['ticker'] for r in chosen}:raise ValueError('조사 수/종목 중복 불일치')
 listed={}
 for filename in ['nasdaqlisted.txt','otherlisted.txt']:
  b=raw['https://www.nasdaqtrader.com/dynamic/symdir/'+filename]
  for row in csv.DictReader(io.StringIO(b.decode('utf-8-sig')),delimiter='|'):
   ticker=row.get('Symbol') or row.get('ACT Symbol');ex='XNAS' if filename=='nasdaqlisted.txt' else {'N':'XNYS','A':'XASE'}.get(row.get('Exchange'))
   name=row.get('Security Name','')
   if ex and row.get('Test Issue')=='N' and row.get('ETF')=='N' and re.search(r'common|ordinary|american depositary|american depository|\bADS\b',name,re.I) and not re.search(r'warrant|\bunits?\b|preferred|depositary shares.*preferred|notes due|rights',name,re.I):listed[ticker]=ex
 for seed in chosen:
  url=seed['priority_source'];q=json.loads(raw[url])['finance']['result'][0]['quotes']
  match=[x for x in q if x.get('symbol')==seed['ticker']]
  if len(match)!=1:raise ValueError('공개 순위 원본 종목 불일치')
  fresh=movement.feed_seed(match[0],session,stamp(recs[url]['retrieved_at']),url)
  if any(seed.get(k)!=v for k,v in fresh.items()):raise ValueError('조사 순위 원본 값 불일치')
  if seed['ticker'] not in listed:raise ValueError('대상 거래소 상장 확인 실패')
 verified_light=[];blocked_light=[]
 for r in light:
  if not safe_flags(r):raise ValueError('조사 행 허위 승인')
  if r.get('exchange')!=listed[r['ticker']]:raise ValueError('거래소 불일치')
  if r['light_status']=='DATA_BLOCKED':blocked_light.append(r['ticker']);continue
  calc=chart(r)
  if r['discovery_lanes']!=movement.lanes(calc) or r['reference_lanes']!=movement.reference_lanes(calc):raise ValueError('조사 선정 경로 불일치')
  verified_light.append(r['ticker'])
 if len(verified_light)!=d['success_count']:raise ValueError('유효 일봉 수 불일치')
 detailed=d['candidates']+d['additional_rows']+d.get('rejected_details',[])
 if len(detailed)!=d['detail_attempted_count'] or len({r['ticker'] for r in detailed})!=len(detailed):raise ValueError('상세 수/중복 오류')
 if {r['ticker'] for r in movement.detail_budget(light,25)}!={r['ticker'] for r in detailed}:raise ValueError('상세 분석 대상 누락/추가')
 accepted=[];errors={}
 for r in detailed:
  try:
   if not safe_flags(r) or r['ticker'] not in verified_light:raise ValueError('안전 차단/일봉 근거 미검증')
   calc=chart(r);e=r['dated_evidence'];url=r['nasdaq_url'];rec=recs[url]
   if not url.startswith('https://api.nasdaq.com/api/quote/'+r['ticker']+'/historical?'):raise ValueError('Nasdaq 출처 URL 오류')
   checked=crosscheck(json.loads(raw[url]),r['ticker'],session,calc)
   if any(e.get(k)!=v for k,v in checked.items()):raise ValueError('Nasdaq 근거 수치 불일치')
   if e['yahoo_session']!=session or stamp(e['regular_close_at'])!=close or e['yahoo_url']!=r['yahoo_url'] or e['nasdaq_url']!=url:raise ValueError('거래일/마감/출처 불일치')
   if not stamp(r['yahoo_retrieved_at'])<=stamp(rec['retrieved_at'])<=stamp(r['nasdaq_retrieved_at'])<=stamp(r['quote_collected_at'])<=selected:raise ValueError('상세 수신 시각 불일치')
   formal=bool(movement.lanes(calc));reference=bool(movement.reference_lanes(calc)) and not formal
   grade='B' if formal else 'C' if reference else 'D'
   if r.get('date_verified') is not True or r.get('observation_grade')!=grade or grade=='D' or r.get('screening_eligible')!=formal or r.get('reference_eligible')!=reference:raise ValueError('원본 규칙 재계산/등급 불일치')
   accepted.append(r['ticker'])
  except (ValueError,KeyError,TypeError,IndexError) as ex:errors[r['ticker']]=str(ex)
 if d['screening_candidate_count']!=sum(r['screening_eligible'] for r in detailed) or d['reference_count']!=sum(r['reference_eligible'] for r in detailed):raise ValueError('후보 집계 불일치')
 incomplete=bool(blocked_light or errors or d['population'].get('feed_errors')) or d['success_count']<100
 count=sum(r['observation_grade']=='B' and r['ticker'] in accepted for r in detailed)
 outcome='OBSERVATIONS_FOUND' if count else 'ZERO_IN_VERIFIED_SCOPE' if not blocked_light and not errors and verified_light else 'CANNOT_DETERMINE_ZERO'
 return d,{'selection_sha256':selection_digest,'receipt_count':len(recs),'accepted_tickers':accepted,'row_errors':errors,'verified_light':len(verified_light),'blocked_light':blocked_light,'formal_count':count,'scope_partial':incomplete,'outcome':outcome,'valid_until':next_close(dt.date.fromisoformat(session)).isoformat(),'entryAllowed':False,'validationStatus':'NOT_VALIDATED'}

def network_integrity(dest):
 """Offline, read-only reconciliation; never fabricates a missing event."""
 dest=pathlib.Path(dest)
 path=dest/'network-events.jsonl'
 if not path.exists():return {'ok':False,'issue':'NETWORK_EVENTS_MISSING'}
 events=[json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
 groups={};problems=[]
 for index,event in enumerate(events):
  request_id=event.get('request_id')
  if not isinstance(request_id,str) or not request_id:
   problems.append({'index':index,'reason':'REQUEST_ID_MISSING'});continue
  group=groups.setdefault(request_id,[])
  if event.get('event')!='REQUEST_STARTED' and not group:
   problems.append({'request_id':request_id,'reason':'RESPONSE_WITHOUT_START'})
  group.append(event.get('event'))
 for request_id,events_for_id in groups.items():
  if events_for_id.count('REQUEST_STARTED')!=1:
   problems.append({'request_id':request_id,'reason':'START_MISSING_OR_DUPLICATE'})
  else:
   journal=dest/'request-journal'/(request_id+'.json')
   if not journal.exists():
    problems.append({'request_id':request_id,'reason':'START_JOURNAL_MISSING'})
   else:
    try:
     journal_start=json.loads(journal.read_text(encoding='utf-8'))
     starts=[x for x in events if x.get('request_id')==request_id and x.get('event')=='REQUEST_STARTED']
     if starts!=[journal_start]:
      problems.append({'request_id':request_id,'reason':'START_JOURNAL_MISMATCH'})
    except (ValueError,OSError):problems.append({'request_id':request_id,'reason':'START_JOURNAL_CORRUPT'})
  if events_for_id[-1] not in ('BODY_SAVED','BODY_ERROR','BODY_INCOMPLETE','ERROR'):
   problems.append({'request_id':request_id,'reason':'NO_FINAL_EVENT'})
 for journal in (dest/'request-journal').glob('*.json'):
  if journal.stem not in groups:
   problems.append({'request_id':journal.stem,'reason':'ORPHAN_START_JOURNAL'})
 return {'ok':not problems,'request_count':len(groups),'event_count':len(events),'problems':problems}

@contextlib.contextmanager
def network_audit(log,dest=None):
 original=urllib.request.urlopen
 guard=threading.Lock()
 def persist(event):
  if dest:
   dest.mkdir(parents=True,exist_ok=True)
   with guard:
    request_id=event['request_id']
    journal=dest/'request-journal'/(request_id+'.json')
    if event['event']=='REQUEST_STARTED':
     journal.parent.mkdir(parents=True,exist_ok=True)
     # Independent, durable start proof survives a torn/shared event stream.
     with journal.open('x',encoding='utf-8') as f:
      json.dump(event,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
    elif not journal.exists():
     raise RuntimeError('REQUEST_STARTED 영수증 없는 후속 네트워크 이벤트 차단')
    with (dest/'network-events.jsonl').open('a',encoding='utf-8') as f:
     f.write(json.dumps(event,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
 class Response:
  def __init__(self,response,item,start):self.response=response;self.item=item;self.start=start;self.parts=[];self.done=False;self.failed=False
  def __getattr__(self,k):return getattr(self.response,k)
  def __enter__(self):return self
  def checkpoint(self,complete=False):
   if not dest:return
   value=b''.join(self.parts);h=sha(value);folder='request-raw' if complete else 'partial-raw';p=dest/folder/(h+'.raw');p.parent.mkdir(parents=True,exist_ok=True)
   with p.open('wb') as f:f.write(value);f.flush();os.fsync(f.fileno())
   persist({**self.item,'event':'BODY_SAVED' if complete else 'BODY_PARTIAL','at':now(),'sha256':h,'bytes':len(value),'complete':complete,'elapsed_seconds':time.monotonic()-self.start})
  def __exit__(self,*args):
   if not self.done and not self.failed:persist({**self.item,'event':'BODY_INCOMPLETE','at':now()})
   self.response.close()
  def read(self,*args,**kwargs):
   try:value=self.response.read(*args,**kwargs)
   except Exception as e:
    self.failed=True
    partial=getattr(e,'partial',b'')
    if isinstance(partial,bytes) and partial:self.parts.append(partial);self.checkpoint(False)
    event={**self.item,'event':'BODY_ERROR','at':now(),'elapsed_seconds':time.monotonic()-self.start,'error_type':type(e).__name__,'reason':'BODY_READ_FAILED'};log.append(event);persist(event);raise
   if self.done:return value
   self.parts.append(value)
   n=args[0] if args else kwargs.get('amt',kwargs.get('size',None))
   complete=n is None or n<0 or (n!=0 and value==b'')
   if complete:
    headers={str(k).lower():str(v) for k,v in getattr(self.response,'headers',{}).items()}
    # urllib exposes encoded representation bytes; Content-Encoding is not decoded here.
    length=headers.get('content-length');chunked='chunked' in headers.get('transfer-encoding','').lower()
    if length is not None and not chunked:
     actual=sum(map(len,self.parts))
     if not length.isdigit() or actual!=int(length):
      self.checkpoint(False);self.failed=True
      event={**self.item,'event':'BODY_ERROR','reason':'CONTENT_LENGTH_MISMATCH','expected_length':length,'actual_bytes':actual,'at':now()};log.append(event);persist(event)
      raise ValueError('Content-Length와 수신 본문 길이 불일치')
   self.checkpoint(complete);self.done=complete
   return value
 def logged(req,*args,**kw):
  url=req.full_url if hasattr(req,'full_url') else str(req);start=time.monotonic();item={'url':url,'at':now(),'request_id':uuid.uuid4().hex,'timeout_seconds':kw.get('timeout')}
  persist({**item,'event':'REQUEST_STARTED'})
  try:
   response=original(req,*args,**kw);item['status']=getattr(response,'status',200);log.append(item);persist({**item,'event':'RESPONSE','elapsed_seconds':time.monotonic()-start});return Response(response,item,start)
  except Exception as e:
   item.update(status=getattr(e,'code',None),error_type=type(e).__name__,reason='HTTP_403' if getattr(e,'code',None)==403 or '403' in str(e) else 'HTTP_OR_NETWORK_ERROR');log.append(item);persist({**item,'event':'ERROR','elapsed_seconds':time.monotonic()-start});raise
 urllib.request.urlopen=logged
 try:yield
 finally:urllib.request.urlopen=original

def supplements(d,dest):
 """Headlines/filing index only, never a contract review or approval."""
 out={};client=Client(os.environ.get('SEC_USER_AGENT'));mapping=None
 agent=os.environ.get('SEC_USER_AGENT','');sec_ready='@' in agent
 if sec_ready:
  try:mapping=client.json('https://www.sec.gov/files/company_tickers.json')
  except Exception: mapping=None
 for r in (d['candidates']+d['additional_rows']+d.get('rejected_details',[]))[:25]:
  ticker=r['ticker'];news_url='https://finance.yahoo.com/rss/headline?s='+urllib.parse.quote(ticker,safe='')
  item={'news_status':'UNCONFIRMED','news':[],'news_source':news_url,'sec_status':'IDENTITY_NOT_CONFIGURED' if not sec_ready else 'UNCONFIRMED','filings':[],'sec_review_verified':False,'entryAllowed':False}
  try:
   b=client.get(news_url);client.log[-1]['url']=news_url;tree=ET.fromstring(b)
   from email.utils import parsedate_to_datetime
   for x in tree.findall('.//item')[:5]:
    pub=x.findtext('pubDate');t=parsedate_to_datetime(pub)
    if t.tzinfo and t<=dt.datetime.now(dt.timezone.utc):item['news'].append({'title':x.findtext('title'),'url':x.findtext('link'),'published_at':t.isoformat()})
   item['news_status']='HEADLINES_ONLY' if item['news'] else 'EMPTY_FEED_NOT_PROOF_OF_NO_NEWS'
  except Exception as ex:item['news_status']='FETCH_FAILED';item['news_error_type']=type(ex).__name__
  if mapping:
   matches=[v for v in mapping.values() if v.get('ticker')==ticker]
   if len(matches)==1:
    cik=str(matches[0]['cik_str']).zfill(10);url='https://data.sec.gov/submissions/CIK'+cik+'.json';item['sec_source']=url
    try:
     sub=client.json(url);recent=sub['filings']['recent']
     for i,acc in enumerate(recent['accessionNumber'][:10]):
      item['filings'].append({'form':recent['form'][i],'filed':recent['filingDate'][i],'url':f'https://www.sec.gov/Archives/edgar/data/{int(cik)}/{acc.replace("-","")}/{recent["primaryDocument"][i]}'})
     item['sec_status']='INDEX_ONLY_NOT_REVIEWED'
    except Exception as ex:item['sec_status']='FETCH_FAILED';item['sec_error_type']=type(ex).__name__
  out[ticker]=item
 for rec in client.log:
  source=ROOT/'cache'/(rec['sha256']+'.raw');p=dest/'supplement-raw'/source.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(source.read_bytes())
 save(dest/'supplements.json',{'rows':out,'source_receipts':client.log,'note':'시세 선정 후 별도 수집. 후보 선정 근거로 소급하지 않음. 뉴스 진위/SEC 계약 미검증.'})
 return out

def completion_check(history,manifest,status):
 """Success needs a persisted completion bound to this attempt and verified raw."""
 history=pathlib.Path(history).resolve();manifest=pathlib.Path(manifest).resolve()
 if status.get('status') not in ('SUCCESS','SUCCESS_PARTIAL'):raise ValueError('실제 attempt 실패/미완료')
 attempt=history.parent
 if attempt.name!=status.get('attempt_id') or attempt.parent.name!='attempts':raise ValueError('실행 ID/경로 불일치')
 persisted=json.loads((attempt/'attempt.json').read_text())
 if persisted!=status:raise ValueError('저장된 attempt 불일치')
 d,proof=verify(history,manifest,require_current=False)
 m=json.loads(manifest.read_text())
 if manifest.parent.name!=d['run_id'] or m.get('session')!=d['session'] or m.get('selected_at')!=d['selection_known_at']:raise ValueError('manifest 실행/날짜 불일치')
 c=json.loads((attempt/'completion.json').read_text())
 expected={'attempt_id':status['attempt_id'],'run_id':d['run_id'],'session':d['session'],'selection_sha256':proof['selection_sha256'],'manifest_sha256':sha(manifest.read_bytes()),'data_sha256':sha(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())}
 if any(c.get(k)!=v for k,v in expected.items()) or c.get('status')!='COMPLETE' or not c.get('completed_at'):raise ValueError('완료 기록 불일치')
 if status.get('run_id')!=d['run_id'] or status.get('session')!=d['session'] or stamp(status['started_at'])>stamp(d['collection_started_at']) or stamp(c['completed_at'])<stamp(d['selection_known_at']):raise ValueError('실행/거래일/완료 시각 불일치')
 return {**expected,'completed_at':c['completed_at'],'verified':True}

def collection_result(home,expected_attempt_ids=None):
 result={'successful_refresh':False,'collection_status':'UNVERIFIED','outcome':'CANNOT_DETERMINE_ZERO','attempt_id':None,'manifest_verified':False}
 try:
  state=json.loads((home/'state.json').read_text());status=state['last_attempt'];result.update(collection_status=status['status'],attempt_id=status.get('attempt_id'))
  if expected_attempt_ids is not None and status.get('attempt_id') not in expected_attempt_ids:raise ValueError('이번 감독 실행에서 생성된 attempt 아님')
  history=inside(home,state['history']);binding=completion_check(history,inside(history,state['manifest']),status)
  result.update(successful_refresh=True,manifest_verified=True,outcome=status['outcome'],completion=binding)
 except Exception as ex:result['reason']=str(ex)
 return result

def build(history,manifest,dest,status,supp=None,require_current=False):
 d,proof=verify(history,manifest,require_current=require_current)
 binding=None
 if status.get('status') in ('SUCCESS','SUCCESS_PARTIAL'):
  try:binding=completion_check(history,manifest,status)
  except Exception as ex:status={**status,'status':'FAILED_LAST_SUCCESS_RETAINED','reason':'완료 근거 검증 실패: '+str(ex)}
 packet={'data':d,'proof':proof,'status':status,'completion':binding,'evidence_location':{'history':str(pathlib.Path(history).resolve()),'manifest':str(pathlib.Path(manifest).resolve())},'selection_source':inside(pathlib.Path(history),json.loads(pathlib.Path(manifest).read_text())['selection_file']).read_text(),'supplements':supp or {}}
 dest.parent.mkdir(parents=True,exist_ok=True)
 p=subprocess.run(['node',str(ROOT/'scripts/build-refresh-ui.mjs'),str(dest)],input=json.dumps(packet),text=True,capture_output=True)
 if p.returncode:raise ValueError('HTML 생성 실패: '+p.stderr[:300])
 save(dest.with_suffix('.proof.json'),proof);return proof

def load_supplements(path):
 if not path or not path.exists():return {}
 try:
  d=json.loads(path.read_text())
  for rec in d['source_receipts']:
   h=rec['sha256']
   if not re.fullmatch('[0-9a-f]{64}',h):raise ValueError('invalid hash')
   b=(path.parent/'supplement-raw'/(h+'.raw')).read_bytes()
   if sha(b)!=h or len(b)!=rec['bytes']:raise ValueError('raw mismatch')
  return d['rows']
 except (ValueError,KeyError,OSError):return {}

def initialize():
 HOME.mkdir(parents=True,exist_ok=True)
 state=HOME/'state.json'
 if not state.exists():
  manifests=list((HOME/'baseline/runs').glob('*/manifest.json'))
  if len(manifests)!=1:raise ValueError('검수 완료 baseline manifest 없음')
  verify(HOME/'baseline',manifests[0],require_current=False)
  atomic(state,{'history':'baseline','manifest':str(manifests[0].relative_to(HOME/'baseline')),'status':'BASELINE_ONLY','attempts':[]})
 return json.loads(state.read_text())

def recover_interrupted():
 """Offline recovery only. Never resumes requests or manufactures a completed selection."""
 state=initialize();lock=HOME/'running.lock'
 if not lock.exists():raise ValueError('복구할 중단 잠금 기록 없음')
 try:
  owner=json.loads(lock.read_text());pid=owner['pid']
  try:os.kill(pid,0)
  except ProcessLookupError:pass
  else:
   actual=process_identity(pid)
   known=owner.get('pid_start_ticks') is not None and owner.get('boot_id')
   if not known or not actual or (actual['pid_start_ticks']==owner['pid_start_ticks'] and actual['boot_id']==owner['boot_id']):
    raise ValueError('동일 PID의 실제 실행 여부를 배제할 수 없음: 복구 금지')
   # Existing PID with a *different* creation identity is a reused PID,
   # not the owner. The lock is preserved as interrupted evidence.
 except json.JSONDecodeError:pass # legacy timestamp-only lock; operator must check process first
 pending=[]
 for attempt in sorted((HOME/'attempts').iterdir()):
  original=json.loads((attempt/'attempt.json').read_text())
  if original['status']=='RUNNING' and str(attempt.relative_to(HOME)) not in state['attempts']:pending.append((attempt,original))
 if len(pending)!=1:raise ValueError('중단 기록이 정확히 1개가 아님')
 attempt,original=pending[0];lights=[json.loads(p.read_text()) for p in attempt.glob('history/runs/*/light/*.json')]
 populations=list(attempt.glob('history/runs/*/population.json'));pop=json.loads(populations[0].read_text()) if populations else {}
 status={**original,'status':'FAILED_LAST_SUCCESS_RETAINED','recovery_at':now(),'reason':'실행 중단 · 완료 선정 원문/manifest 없음. 중단 원인 미확정. 추가 수집하지 않음.','selected_for_light':len(pop.get('chosen',[])),'saved_light_records':len(lights),'saved_light_marked_valid':sum(r['light_status']!='DATA_BLOCKED' for r in lights),'details':None,'formal':None,'additional':None,'outcome':'CANNOT_DETERMINE_ZERO','observed_403_minimum':sum('403' in r.get('error','') for r in lights),'http_403_count':None,'note':'403은 저장된 행 오류의 최소 확인 수. 전체 요청 로그가 없어 총수 미확인.'}
 evidence=[]
 for p in (ROOT/'cache').glob('*.raw'):
  b=p.read_bytes();h=sha(b);dest=attempt/'recovered-cache'/(h+'.raw');dest.parent.mkdir(exist_ok=True);dest.write_bytes(b);evidence.append({'sha256':h,'bytes':len(b),'source_url':'기존 light/population의 출처와 별도 대조 필요','retrieved_at':None})
 save(attempt/'recovered-cache-index.json',evidence);save(attempt/'recovery.json',status)
 state['attempts'].append(str(attempt.relative_to(HOME)));state['last_attempt']=status
 supp=load_supplements(inside(HOME,state['supplements'])) if state.get('supplements') else {}
 build(inside(HOME,state['history']),inside(inside(HOME,state['history']),state['manifest']),HOME/'exports/LUCA_REFRESH_IPHONE.html',status,supp)
 atomic(HOME/'state.json',state);lock.rename(attempt/'interrupted-lock.txt');print(json.dumps(status,ensure_ascii=False));return status

def perform(collect_once=False):
 state=initialize();export=HOME/'exports';export.mkdir(exist_ok=True)
 if not collect_once:
  supp=load_supplements(inside(HOME,state['supplements'])) if state.get('supplements') else {}
  proof=build(inside(HOME,state['history']),inside(inside(HOME,state['history']),state['manifest']),export/'LUCA_REFRESH_IPHONE.html',state.get('last_attempt',{'status':'BASELINE_ONLY'}),supp)
  print(json.dumps(proof,ensure_ascii=False));return
 lock=HOME/'running.lock'
 with lock.open('x') as f:
  json.dump({'pid':os.getpid(),'started_at':now(),**(process_identity(os.getpid()) or {})},f)
  f.flush();os.fsync(f.fileno())
 attempt_id=now().replace(':','-')+'-'+uuid.uuid4().hex[:8];attempt=HOME/'attempts'/attempt_id;attempt.mkdir(parents=True)
 def stage(name):
  with (attempt/'stages.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'stage':name,'at':now()})+'\n');f.flush();os.fsync(f.fileno())
 events=[];status={'attempt_id':attempt_id,'started_at':now(),'status':'RUNNING','collection_calls':1,'entryAllowed':False,'validationStatus':'NOT_VALIDATED'}
 save(attempt/'attempt.json',status);log=(attempt/'execution.log').open('w',buffering=1,encoding='utf-8');supp={};cache_before={p.name for p in (ROOT/'cache').glob('*.raw')}
 try:
  with contextlib.redirect_stdout(log),network_audit(events,attempt):
   try:
    stage('COLLECTING')
    data=movement.run(100,25,attempt/'history',attempt/'no-previous',allow_partial=True)
    manifest=attempt/'history/runs'/data['run_id']/'manifest.json'
    stage('VERIFYING_RAW')
    _,proof=verify(attempt/'history',manifest,require_current=True)
    if not proof['verified_light']:raise ValueError('날짜 검증 일봉 0개: 후보 0개 아님')
    stage('SUPPLEMENT_COLLECTION')
    supp=supplements(data,attempt)
    integrity=network_integrity(attempt)
    save(attempt/'network-integrity.json',integrity)
    if not integrity['ok']:raise ValueError('네트워크 요청 로그 시작/종료 증거 불일치: 정식 완료 차단')
    status.update(status='SUCCESS_PARTIAL' if proof['scope_partial'] else 'SUCCESS',session=data['session'],attempted=data['attempted_count'],dated=proof['verified_light'],details=data['detail_attempted_count'],formal=proof['formal_count'],additional=sum(r['observation_grade']=='C' and r['ticker'] in proof['accepted_tickers'] for r in data['additional_rows']),outcome=proof['outcome'])
    status['run_id']=data['run_id']
    save(attempt/'attempt.json',status)
    save(attempt/'completion.json',{'status':'COMPLETE','completed_at':now(),'attempt_id':attempt_id,'run_id':data['run_id'],'session':data['session'],'selection_sha256':proof['selection_sha256'],'manifest_sha256':sha(manifest.read_bytes()),'data_sha256':sha(json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())})
    stage('BUILDING_HTML')
    build(attempt/'history',manifest,attempt/'LUCA_REFRESH_IPHONE.html',status,supp,require_current=True)
    state.update(history=str((attempt/'history').relative_to(HOME)),manifest=str(manifest.relative_to(attempt/'history')),supplements=str((attempt/'supplements.json').relative_to(HOME)))
   except Exception as ex:
    stage('FAILED')
    status.update(status='FAILED_LAST_SUCCESS_RETAINED',error_type=type(ex).__name__,reason=str(ex)[:400],outcome='CANNOT_DETERMINE_ZERO')
    # Capture raw receipts even when original collector exits before manifest creation.
    save(attempt/'collector-receipts.json',radar.SOURCE_LOG)
    for rec in radar.SOURCE_LOG:
     p=ROOT/'cache'/(rec['sha256']+'.raw')
     if p.exists():q=attempt/'available-raw'/p.name;q.parent.mkdir(exist_ok=True);q.write_bytes(p.read_bytes())
    for p in (ROOT/'cache').glob('*.raw'):
     if p.name not in cache_before:q=attempt/'available-raw'/p.name;q.parent.mkdir(exist_ok=True);q.write_bytes(p.read_bytes())
    pops=list((attempt/'history/runs').glob('*/population.json'))
    pop=json.loads(pops[-1].read_text()) if pops else {}
    lights=list((attempt/'history/runs').glob('*/light/*.json'))
    status.update(selected_for_light=len(pop.get('chosen',[])),attempted=len(lights),dated=None,details=None,formal=None,additional=None)
  status.update(finished_at=now(),http_403_count=sum(x.get('status')==403 or x.get('reason')=='HTTP_403' for x in events),network_error_count=sum('error_type' in x for x in events))
  save(attempt/'network-log.json',events);save(attempt/'attempt.json',status);log.flush()
  state['attempts'].append(str(attempt.relative_to(HOME)));state['last_attempt']=status
  if status['status']=='FAILED_LAST_SUCCESS_RETAINED':supp=load_supplements(inside(HOME,state['supplements'])) if state.get('supplements') else {}
  # Always rebuild the banner; on failure the last validated selection pointer stays unchanged.
  build(inside(HOME,state['history']),inside(inside(HOME,state['history']),state['manifest']),export/'LUCA_REFRESH_IPHONE.html',status,supp)
  atomic(HOME/'state.json',state);stage('FINISHED');print(json.dumps(status,ensure_ascii=False))
 finally:log.close();lock.unlink(missing_ok=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description='별도 연구판: 수동 1회 수집 후 오프라인 HTML 생성. 주문/배포 없음.')
 mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--collect-once',action='store_true');mode.add_argument('--rebuild',action='store_true');mode.add_argument('--recover-interrupted',action='store_true');args=p.parse_args()
 if args.recover_interrupted:recover_interrupted()
 else:perform(args.collect_once)
