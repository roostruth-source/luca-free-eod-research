"""Single monitored run, 20-minute wall limit, no retries and no schedule."""
import datetime as dt,json,os,pathlib,subprocess,sys,time
from refresh import collection_result
ROOT=pathlib.Path(__file__).resolve().parents[1]
HOME=pathlib.Path(os.environ['LUCA_RESEARCH_HOME']).expanduser().resolve() if os.environ.get('LUCA_RESEARCH_HOME') else ROOT/'local-data/manual-refresh-research'
LIMIT_SECONDS=1200
def write(path,data):
 tmp=path.with_suffix('.tmp')
 with tmp.open('w') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
 tmp.replace(path)
def main():
 HOME.mkdir(parents=True,exist_ok=True)
 # A second invocation requires a separately reviewed copy; never repeat automatically.
 marker=HOME/'stability-once.json'
 with marker.open('x') as f:json.dump({'started_at':dt.datetime.now(dt.timezone.utc).isoformat(),'limit_seconds':LIMIT_SECONDS,'collector_launches':1},f)
 previous_attempts={p.name for p in (HOME/'attempts').glob('*')}
 start=time.monotonic();timed_out=False
 # Save a durable RUNNING result *before* launching the child. If an external
 # environment kills this supervisor without a Python finalizer, the missing
 # FINISHED status remains an explicit unverified interruption.
 write(HOME/'supervisor-result.json',{'status':'RUNNING','successful_refresh':False,'manifest_verified':False,'outcome':'CANNOT_DETERMINE_ZERO','started_at':dt.datetime.now(dt.timezone.utc).isoformat(),'supervisor_pid':os.getpid(),'automatic_retries':0,'collector_launches':0})
 with (HOME/'supervisor.log').open('w',buffering=1) as log:
  try:child=subprocess.Popen([sys.executable,'-u',str(ROOT/'research/refresh.py'),'--collect-once'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
  except Exception as ex:
   write(HOME/'supervisor-result.json',{'status':'LAUNCH_FAILED','successful_refresh':False,'manifest_verified':False,'outcome':'CANNOT_DETERMINE_ZERO','error_type':type(ex).__name__,'reason':str(ex)[:200],'automatic_retries':0,'collector_launches':0})
   return 1
  write(HOME/'supervisor-result.json',{'status':'RUNNING','successful_refresh':False,'manifest_verified':False,'outcome':'CANNOT_DETERMINE_ZERO','started_at':dt.datetime.now(dt.timezone.utc).isoformat(),'supervisor_pid':os.getpid(),'child_pid':child.pid,'automatic_retries':0,'collector_launches':1})
  progress={'pid':child.pid,'light_records':0,'selection_files':0,'at':dt.datetime.now(dt.timezone.utc).isoformat()}
  while child.poll() is None:
   attempts=list((HOME/'attempts').glob('*'));a=max(attempts,key=lambda p:p.name) if attempts else None
   progress={'elapsed_seconds':time.monotonic()-start,'pid':child.pid,'alive':True,'light_records':len(list(a.glob('history/runs/*/light/*.json'))) if a else 0,'selection_files':len(list(a.glob('history/selections/*/*.json'))) if a else 0,'at':dt.datetime.now(dt.timezone.utc).isoformat()}
   write(HOME/'progress.json',progress)
   if time.monotonic()-start>=LIMIT_SECONDS:
    timed_out=True;child.terminate()
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:child.kill();child.wait()
    break
   time.sleep(1)
  result={'status':'CHILD_FINISHED_UNVERIFIED','successful_refresh':False,'manifest_verified':False,'outcome':'CANNOT_DETERMINE_ZERO','exit_code':child.returncode,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,'collector_launches':1,'automatic_retries':0}
  write(HOME/'supervisor-result.json',result)
  progress.update(alive=False,exit_code=child.returncode,timed_out=timed_out,elapsed_seconds=time.monotonic()-start);write(HOME/'progress.json',progress)
  if (HOME/'running.lock').exists():
   recovered=subprocess.run([sys.executable,str(ROOT/'research/refresh.py'),'--recover-interrupted'],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,timeout=60)
   result['offline_recovery_exit_code']=recovered.returncode;write(HOME/'supervisor-result.json',result)
 result.update(collection_result(HOME,{p.name for p in (HOME/'attempts').glob('*')}-previous_attempts))
 if child.returncode!=0 or timed_out:result.update(successful_refresh=False,collection_status='PROCESS_FAILED',outcome='CANNOT_DETERMINE_ZERO')
 result['status']='FINISHED_VERIFIED' if result['successful_refresh'] and child.returncode==0 else 'FINISHED_FAILED'
 write(HOME/'supervisor-result.json',result)
 print(json.dumps(result));return 0 if result['successful_refresh'] and child.returncode==0 else 1
if __name__=='__main__':sys.exit(main())
