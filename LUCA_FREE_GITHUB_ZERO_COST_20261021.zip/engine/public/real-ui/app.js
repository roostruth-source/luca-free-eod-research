(function(root){
'use strict';
const M=root.LucaUI;
function card(r){return '<article class="card"><div class="card-top"><div><span class="eyebrow">실제 저장 자료 · 과거 종가</span><h2>'+M.esc(r.name)+'</h2><small>'+M.esc(r.ticker)+'</small></div><span class="grade grade-'+r.grade+'" aria-label="'+r.grade+'등급 · 수집 당시">'+r.grade+'</span></div><p><span class="pill">'+M.esc(M.lanes[r.lane])+'</span></p><dl><dt>왜 관찰하나요?</dt><dd>'+M.esc(r.reason)+'</dd><dt>어떤 위험이 있나요?</dt><dd class="warning">'+M.esc(r.risk)+'</dd><dt>지금 무엇을 해야 하나요?</dt><dd>'+M.esc(r.action)+'</dd></dl><p class="notice">실시간 미연결<br>과거 확인 종가 '+M.esc(M.formatPrice(r.price))+'<br><small>공급처 시세 시각 '+M.esc(M.time(r.priceAt))+'</small><small>발견 '+M.esc(M.time(r.foundAt))+'</small><small>'+M.esc(M.sessions[r.session]||'시간대 미확인')+' · 완료 일봉</small></p><p class="hint warning">'+M.esc(M.freshness(r))+'</p><details><summary>검토할 가격 · 모두 확인 필요</summary>'+M.priceMarkup(r)+'</details><button type="button" data-open="'+M.esc(r.ticker)+'">관찰 이유·위험 자세히 보기</button><small>실제 매수 불가 · 성과 미검증</small></article>';}
function boot(doc,source=root.LUCA_REAL_ROWS){
 const rows=(source||[]).map(M.normalize);let grade='all',lane='all',query='',opener=null;
 const $=id=>doc.getElementById(id);
 function render(){
  const n=M.counts(rows);for(const g of ['A','B','C','D'])$('count-'+g).textContent=n[g];
  const selected=M.select(rows,grade,lane,query);
  $('result-count').textContent='표시 종목 '+selected.length+'개 · 상세 분석 14개 + 일봉 차단 3개';
  $('cards').innerHTML=selected.length?selected.map(card).join(''):'<section class="empty"><h2>'+(grade==='A'?'A등급은 현재 사용하지 않습니다.':'해당하는 종목이 없습니다.')+'</h2><p>조건을 낮추거나 다른 종목으로 채우지 않습니다.</p><button id="clear-empty" type="button">전체 종목 보기</button></section>';
  doc.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>{
   const r=rows.find(x=>x.ticker===b.dataset.open);if(!r)return;
   opener=b;$('detail-body').innerHTML=M.detail(r);
   if(typeof $('detail').showModal==='function')$('detail').showModal();else $('detail').setAttribute('open','');
   $('close-detail').focus();
  });
  if($('clear-empty'))$('clear-empty').onclick=reset;
  doc.querySelectorAll('[data-grade]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.grade===grade)));
  doc.querySelectorAll('[data-lane]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.lane===lane)));
 }
 function reset(){grade='all';lane='all';query='';$('search').value='';render();}
 function close(){if(typeof $('detail').close==='function')$('detail').close();else $('detail').removeAttribute('open');if(opener)opener.focus();}
 function download(name,text,type){
  try {const u=URL.createObjectURL(new Blob([text],{type}));const a=doc.createElement('a');a.href=u;a.download=name;doc.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);$('download-status').textContent='파일 열기 또는 저장을 요청했습니다. 아이폰에서는 공유 → 파일에 저장을 확인하세요.';}
  catch(e){$('download-status').textContent='이 미리보기에서 파일 저장을 지원하지 않습니다. 함께 제공한 ZIP을 이용하세요.';}
 }
 doc.querySelectorAll('[data-grade]').forEach(b=>b.onclick=()=>{grade=b.dataset.grade;render();});
 doc.querySelectorAll('[data-lane]').forEach(b=>b.onclick=()=>{lane=b.dataset.lane;render();});
 $('search').oninput=e=>{query=e.target.value;render();};$('reset').onclick=reset;$('close-detail').onclick=close;
 $('detail').addEventListener('close',()=>{if(opener)opener.focus();});
 $('export-json').onclick=()=>download('LUCA_REAL_DISPLAY.json',JSON.stringify({dataKind:'real-observation-snapshot',purpose:'과거 자료 읽기 전용',entryAllowed:false,validationStatus:'NOT_VALIDATED',rows},null,2),'application/json');
 $('export-guide').onclick=()=>download('LUCA_UI_GUIDE.txt',root.LUCA_GUIDE,'text/plain;charset=utf-8');
 $('export-source').onclick=()=>download('LUCA_SOURCE_ORIGINAL.json',JSON.stringify(root.LUCA_PAYLOAD,null,2),'application/json');
 render();$('interactive-state').textContent='버튼 사용 가능 · 표시 종목 전용';return {render,reset,rows};
}
root.LucaUIApp={card,boot};
if(typeof document!=='undefined'&&document.getElementById('cards'))boot(document);
})(globalThis);
