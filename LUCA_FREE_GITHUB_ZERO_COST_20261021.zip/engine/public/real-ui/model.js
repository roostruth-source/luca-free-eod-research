/* Isolated presentation model. No collectors, APIs, persistence or price engine. */
(function(root){
'use strict';
const UNKNOWN='산출 불가 · 확인 필요';
const grades={A:'최우선 관찰 · 현재 미사용',B:'정식 조건 관찰',C:'추가 관찰',D:'판단 제한·차단'};
const lanes={up:'상승 전조 관찰',down:'급락·반등 관찰',late:'이미 급등한 종목',blocked:'위험·자료 미확인'};
const sessions={day:'한국 데이장',pre:'미국 프리마켓',regular:'미국 정규장',after:'미국 애프터마켓'};
const priceFields=['매수 검토 가격 구간','1차 목표 매도가','2차 목표 매도가','손절 기준 가격','추격 매수 금지 가격','예상 수익 대비 손실 비율'];
const risks=[['sec','SEC 공시','미국 금융감독기관에 제출한 회사 자료'],['atm','ATM','회사가 시장에서 새 주식을 파는 방식'],['warrant','워런트','정해진 조건으로 새 주식을 받을 권리'],['convertible','전환사채','주식으로 바뀔 수 있는 빚'],['float','Float · 유통주식수','시장에서 실제 거래 가능한 주식 수'],['short','공매도','주식을 빌려 팔고 나중에 갚는 거래'],['listing','상장유지','거래소에 계속 남을 수 있는 조건'],['split','주식병합','여러 주식을 한 주로 합치는 조치']];
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function validTime(x){return typeof x==='string'&&/T.*(?:Z|[+-]\d\d:\d\d)$/.test(x)&&Number.isFinite(Date.parse(x));}
function time(x){return validTime(x)?new Date(x).toLocaleString('ko-KR',{timeZone:'Asia/Seoul',hour12:false})+' 한국시간':'미확인';}
function normalize(row){
 // Only bundled example rows may illustrate B/C. Arbitrary real payloads fail closed.
 const demo=row?.dataKind==='synthetic'&&/^DEMO-\d{2}$/.test(row?.ticker||'');
 const g=demo&&['B','C','D'].includes(row.grade)?row.grade:'D';
 const price=demo&&typeof row.price==='number'&&Number.isFinite(row.price)&&row.price>0?row.price:null;
 const lane=g==='D'?'blocked':Object.hasOwn(lanes,row.lane)?row.lane:'blocked';
 return {ticker:demo?row.ticker:'미연결 자료',name:demo?String(row.name||'가상 회사'):'실제 데이터 표시 차단',dataKind:demo?'synthetic':'unverified',grade:g,lane,
  reason:demo?String(row.reason||'근거 미확인'):'실제 자료 연결과 원본 검증이 완료되지 않았습니다.',
  risk:demo?String(row.risk||'위험 미확인'):'SEC·시세·상장유지 위험 미검증',
  action:demo?String(row.action||'자료 확인 전 관망'):'검증된 자료가 연결될 때까지 관망하세요.',
  price,priceAt:demo&&validTime(row.priceAt)?row.priceAt:null,foundAt:demo&&validTime(row.foundAt)?row.foundAt:null,
  session:demo&&Object.hasOwn(sessions,row.session)?row.session:null,
  change:demo&&typeof row.change==='number'&&Number.isFinite(row.change)?row.change:null,
  volume:demo&&typeof row.volume==='number'&&Number.isFinite(row.volume)&&row.volume>0?row.volume:null,
  rvol:demo&&typeof row.rvol==='number'&&Number.isFinite(row.rvol)&&row.rvol>0?row.rvol:null,
  confirmed:demo&&row.confirmed==='example-warrant'?'example-warrant':null,
  entryAllowed:false,entry_allowed:false,simulationEligible:false,validationStatus:'NOT_VALIDATED',
  pricePlan:Object.fromEntries(priceFields.map(k=>[k,UNKNOWN]))};
}
function freshness(r,now=Date.now()){
 if(!r.priceAt)return '가격 기준 시각 미확인 · 판단 차단';
 if(Date.parse(r.priceAt)>now)return '미래 시각 자료 · 판단 차단';
 return '과거 가상 자료 · 현재 시세로 사용 불가';
}
function select(rows,grade='all',lane='all',query=''){
 const q=query.trim().toLowerCase();return rows.filter(r=>(grade==='all'||r.grade===grade)&&(lane==='all'||r.lane===lane)&&(!q||(r.ticker+' '+r.name).toLowerCase().includes(q)));
}
function counts(rows){return Object.fromEntries(['A','B','C','D'].map(g=>[g,rows.filter(r=>r.grade===g).length]));}
function priceMarkup(r){return '<dl class="prices">'+Object.entries(r.pricePlan).map(([k,v])=>'<div><dt>'+esc(k)+'</dt><dd>'+esc(v)+'</dd></div>').join('')+'</dl><p class="muted">지지·저항(멈추거나 되밀린 가격), 거래량, 변동폭, 매수·매도 호가 차이의 검증 자료가 필요합니다. 현재 계산기는 연결하지 않았습니다.</p><p class="notice">매수 검토 가격은 안전성이 검증된 매수 추천이 아닙니다. 목표가 도달·체결은 보장되지 않습니다.</p>';}
function detail(r){
 return '<div class="detail-head"><span class="eyebrow">가상 화면 예시 · 실제 매수 불가</span><h2>'+esc(r.ticker)+' · '+esc(r.name)+'</h2><p>'+esc(grades[r.grade])+' / '+esc(lanes[r.lane])+'</p></div>'+
 '<section><h3>① 왜 관찰하나요?</h3><p>'+esc(r.reason)+'</p><p class="muted">화면 동작을 확인하기 위한 가상 근거입니다. 실제 종목 분석이 아닙니다.</p></section>'+
 '<section><h3>② 어떤 위험이 있나요?</h3><p class="warning">'+esc(r.risk)+'</p><dl class="risk-list">'+risks.map(([id,name,meaning])=>'<div><dt>'+esc(name)+'<small>'+esc(meaning)+'</small></dt><dd>'+(r.confirmed==='example-warrant'&&id==='warrant'?'가상 설정 있음 · 실제 확인 아님':'미확인')+'</dd></div>').join('')+'</dl></section>'+
 '<section><h3>③ 지금 무엇을 해야 하나요?</h3><p>'+esc(r.action)+'</p><p class="notice">모든 종목 실제 매수 불가 · 등급은 관찰 순서만 뜻합니다.</p></section>'+
 '<section><h3>④ 어느 가격을 확인해야 하나요?</h3><p>현재가: 데이터 미연결</p><p>가상 예시 가격: '+(r.price===null?'미확인':'$'+r.price.toFixed(2))+'</p><p class="muted">가격 기준: '+esc(time(r.priceAt))+'<br>발견 시각: '+esc(time(r.foundAt))+'<br>시세 구분: '+esc(sessions[r.session]||'미확인')+' · 가상 설정<br>발견 시간대: '+(r.foundAt?'미국 장 마감 후 · 가상 설정':'미확인')+'</p>'+priceMarkup(r)+'</section>'+
 '<details><summary>복잡한 숫자·자료 상태 보기</summary><p>아래 숫자는 모두 가상이며 정규장 예시만 사용합니다.</p><p>가격 변화 '+(r.change===null?'미확인':esc(r.change)+'%')+' · 거래량 '+(r.volume===null?'미확인':r.volume.toLocaleString('ko-KR')+'주')+' · 평소 거래량 대비 '+(r.rvol===null?'미확인':esc(r.rvol)+'배')+'</p><p>프리장·데이장 거래량 합산 없음 · 실제 원본 출처 미연결</p><p>실제 성과: NOT_VALIDATED · 실거래 검증 없음</p></details>';
}
root.LucaUI=Object.freeze({UNKNOWN,grades,lanes,sessions,priceFields,risks,esc,time,validTime,normalize,freshness,select,counts,priceMarkup,detail});
})(globalThis);
