/* Deliberately fictional names/tickers. Not market observations. */
globalThis.LUCA_EXAMPLES=[
 {ticker:'DEMO-01',name:'가상 새싹',grade:'B',lane:'up',price:2.10,change:4.2,volume:360000,rvol:2.3,reason:'가상 정규장 거래량이 평소의 2.3배입니다. 완만한 상승 조건을 충족한 화면 예시입니다.',risk:'증자와 상장유지 위험이 미확인입니다. B등급이어도 매수할 수 없습니다.',action:'관망하며 회사 공시와 최신 호가를 확인하세요.'},
 {ticker:'DEMO-02',name:'가상 물결',grade:'C',lane:'up',price:1.35,change:7.1,volume:180000,rvol:1.4,reason:'가상 가격 움직임은 있지만 거래량이 정식 관찰 조건에 부족한 예시입니다.',risk:'유통주식수와 공매도 자료가 미확인입니다.',action:'거래량이 이어지는지 추가 관찰하고, 증자 공시를 먼저 확인하세요.'},
 {ticker:'DEMO-03',name:'가상 낙엽',grade:'C',lane:'down',price:.85,change:-18,volume:520000,rvol:3.1,reason:'가상 급락 중 거래가 늘어난 예시입니다. 반등이 확인됐다는 뜻은 아닙니다.',risk:'워런트가 있다고 가정한 화면입니다. 실제 계약·행사 수량은 미확인입니다.',confirmed:'example-warrant',action:'하락이 멈췄다고 단정하지 말고 공시와 호가를 먼저 확인하세요.'},
 {ticker:'DEMO-04',name:'가상 불꽃',grade:'C',lane:'late',price:3.20,change:48,volume:2400000,rvol:8,reason:'가상 하루 상승률이 이미 48%인 뒤 발견한 예시입니다. 급등 전 포착 성공이 아닙니다.',risk:'급등 뒤 되밀림과 매도물량을 확인하지 못했습니다.',action:'추격을 피하고 추가 공시와 가격 안정 여부를 확인하세요.'},
 {ticker:'DEMO-05',name:'가상 안개',grade:'D',lane:'blocked',price:null,change:null,volume:null,rvol:null,reason:'두 출처의 가격이 다르다고 가정한 예시입니다. 관찰 근거로 사용할 수 없습니다.',risk:'가격 불일치 · 위험 정보 부족 · 판단 차단',action:'같은 거래일의 원본 가격을 대조하기 전에는 제외하세요.'}
].map(r=>({...r,dataKind:'synthetic',session:'regular',priceAt:r.price===null?null:'2026-10-13T20:00:00Z',foundAt:'2026-10-13T20:30:00Z'}));
