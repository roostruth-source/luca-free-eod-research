import unittest,tempfile,pathlib,sys,json,shutil,subprocess,copy,datetime as dt
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'research'))
import refresh as R
class CompletionMatchTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();a=pathlib.Path(cls.tmp.name)/'attempts/fixture';h=a/'history';shutil.copytree(R.HOME/'baseline',h);m=next((h/'runs').glob('*/manifest.json'));d,proof=R.verify(h,m,require_current=False)
  status={'status':'SUCCESS','attempt_id':'fixture','run_id':d['run_id'],'session':d['session'],'started_at':d['collection_started_at']};R.save(a/'attempt.json',status)
  R.save(a/'completion.json',{'status':'COMPLETE','completed_at':d['selection_known_at'],'attempt_id':'fixture','run_id':d['run_id'],'session':d['session'],'selection_sha256':proof['selection_sha256'],'manifest_sha256':R.sha(m.read_bytes()),'data_sha256':R.sha(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())})
  cls.packet={'data':d,'proof':proof,'status':status,'completion':R.completion_check(h,m,status),'evidence_location':{'history':str(h),'manifest':str(m)},'selection_source':(h/json.loads(m.read_text())['selection_file']).read_text(),'supplements':{}}
  cls.expiry=int(dt.datetime.fromisoformat(proof['valid_until']).timestamp()*1000)
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def render(self,p,expired=False):
  # Only offline test clock changes. Production uses actual time.
  js="import {render} from './scripts/build-refresh-ui.mjs';import fs from 'node:fs';Date.now=()=>"+str(self.expiry+(1 if expired else -1000))+";process.stdout.write(render(JSON.parse(fs.readFileSync(0,'utf8'))));"
  q=subprocess.run(['node','--input-type=module','-e',js],cwd=R.ROOT,input=json.dumps(p),text=True,capture_output=True);self.assertEqual(q.returncode,0,q.stderr);return q.stdout
 def test_normal_current_completion(self):self.assertIn('<strong>새 수집 완료',self.render(self.packet))
 def test_expired_completion(self):
  html=self.render(self.packet,True);self.assertIn('과거 수집 완료 자료 · 유효기간 만료',html);self.assertNotIn('<strong>새 수집 완료',html)
 def test_forged_manifest_hash(self):
  p=copy.deepcopy(self.packet);p['completion']['manifest_sha256']='a'*64;self.assertIn('갱신 실패',self.render(p))
 def test_missing_completion(self):
  p=copy.deepcopy(self.packet);p.pop('completion');self.assertNotIn('<strong>새 수집 완료',self.render(p))
 def test_any_changed_completion_field(self):
  for key in self.packet['completion']:
   with self.subTest(key=key):
    p=copy.deepcopy(self.packet);p['completion'][key]='modified';self.assertNotIn('<strong>새 수집 완료',self.render(p))
 def test_extra_field_and_boolean_type(self):
  for update in [{'unexpected':1},{'verified':1}]:
   p=copy.deepcopy(self.packet);p['completion'].update(update);self.assertNotIn('<strong>새 수집 완료',self.render(p))
