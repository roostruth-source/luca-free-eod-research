// Internal renderer. Public entry point is research/refresh.py, which verifies raw evidence first.
import {spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dir=path.join(root,'public/real-ui');
const read=f=>fs.readFileSync(path.join(dir,f),'utf8');
const canon=x=>JSON.stringify(x&&typeof x==='object'?Array.isArray(x)?x.map(v=>JSON.parse(canon(v))):Object.fromEntries(Object.keys(x).sort().map(k=>[k,JSON.parse(canon(x[k]))])):x);
export function render(packet){
 const {data:d,proof,supplements={}}=packet;let status=packet.status;
 const cpl=packet.completion, hash=x=>createHash('sha256').update(x).digest('hex');
 const bound=cpl?.verified===true&&cpl.attempt_id===status.attempt_id&&cpl.run_id===d.run_id&&status.run_id===d.run_id&&cpl.session===d.session&&status.session===d.session&&cpl.selection_sha256===proof?.selection_sha256&&/^[a-f0-9]{64}$/.test(cpl.manifest_sha256||'')&&typeof packet.selection_source==='string'&&hash(packet.selection_source)===proof.selection_sha256&&canon(JSON.parse(packet.selection_source))===canon(d)&&Number.isFinite(Date.parse(cpl.completed_at))&&Date.parse(cpl.completed_at)>=Date.parse(d.selection_known_at)&&Date.parse(status.started_at)<=Date.parse(d.collection_started_at);
 const gate=['SUCCESS','SUCCESS_PARTIAL'].includes(status.status)?spawnSync(process.env.LUCA_PYTHON||'python3',[path.join(root,'research/validate_render.py')],{input:JSON.stringify(packet),encoding:'utf8',timeout:30000}):null;
 const diskVerified=gate?.status===0&&gate.stdout.trim()==='{\"verified\": true}';
 if(!['BASELINE_ONLY','FAILED_LAST_SUCCESS_RETAINED'].includes(status.status)&&(!bound||!diskVerified))status={...status,status:'FAILED_LAST_SUCCESS_RETAINED',reason:'실행·원본·완료 기록 일치 확인 실패'};
 if(!proof||!Array.isArray(proof.accepted_tickers)||proof.entryAllowed!==false||proof.validationStatus!=='NOT_VALIDATED')throw Error('검증 결과 없음');
 const c={URL};vm.createContext(c);vm.runInContext(read('model.js'),c);const M=c.LucaUI,esc=M.esc;
 const detail=[...d.candidates,...d.additional_rows,...(d.rejected_details||[])];
 const display=[...detail,...d.light_results.filter(r=>r.light_status==='DATA_BLOCKED'&&!detail.some(x=>x.ticker===r.ticker))];
 const metaKeys=['kind','research_track','session','selection_known_at','collection_started_at','generated_at','run_id','source_receipts'];
 const pins=Object.fromEntries(detail.filter(r=>proof.accepted_tickers.includes(r.ticker)).map(r=>[r.ticker,canon(r)]));
 let model=read('real-model.js').replace(/^const pinnedRows=.*;$/m,()=>`const pinnedRows=Object.freeze(${JSON.stringify(pins)});`).replace(/^const pinnedMeta=.*;$/m,()=>`const pinnedMeta=${JSON.stringify(canon(Object.fromEntries(metaKeys.map(k=>[k,d[k]]))))};`);
 const inputs=`globalThis.LUCA_PAYLOAD=${JSON.stringify(d)};globalThis.LUCA_REFRESH=${JSON.stringify({proof,status,supplements})};`;
 const extension=`(function(root){
 const old=root.LucaUI,esc=old.esc,meta=root.LUCA_REFRESH;
 function expired(){return !Number.isFinite(Date.parse(meta.proof.valid_until))||Date.now()>=Date.parse(meta.proof.valid_until);}
 function normalize(e){let r=old.normalize(e);if(expired()||meta.proof.row_errors[r.ticker])r={...r,grade:'D',lane:'blocked',price:null,priceAt:null,reason:expired()?'다음 거래일 마감이 지났습니다 · 새 수집 전 판단 차단':'원본 검증 실패 · '+meta.proof.row_errors[r.ticker]};return r;}
 function link(x){try{const u=new URL(x);return u.protocol==='https:'?esc(u.href):null;}catch{return null;}}
 function detail(r){const s=meta.supplements[r.ticker]||{},news=s.news||[],filings=s.filings||[];return old.detail(r)+'<section><h3>추가로 확인할 뉴스·공시</h3><p>시세 선정 이후 따로 수집한 목록입니다. 내용 진위와 증자 계약은 미검증입니다.</p><p>'+(!s.news_status?'뉴스 수집 기록 없음':s.news_status==='FETCH_FAILED'?'뉴스 수집 실패 · 뉴스가 없다는 뜻이 아닙니다.':s.news_status==='HEADLINES_ONLY'?'뉴스 제목만 확인 · 원문 및 종목 관련성 추가 확인 필요':'뉴스 내용 미확인')+'</p>'+news.map(n=>'<p>'+esc(n.title)+'<small>'+esc(n.published_at)+'</small>'+(link(n.url)?'<a href="'+link(n.url)+'" target="_blank" rel="noopener noreferrer">기사 출처 보기</a>':'출처 미확인')+'</p>').join('')+'<p>'+(!s.sec_status||s.sec_status==='IDENTITY_NOT_CONFIGURED'?'SEC 수집용 연락처 설정 없음 · 공시 미수집':s.sec_status==='INDEX_ONLY_NOT_REVIEWED'?'SEC 공시 목록만 확인 · 계약 본문 미검토':'SEC 수집 실패 또는 자료 미확인')+'</p>'+filings.map(f=>'<p>'+esc(f.form)+' · '+esc(f.filed)+(link(f.url)?' <a href="'+link(f.url)+'" target="_blank" rel="noopener noreferrer">SEC 원문</a>':'')+'</p>').join('')+'<p>모든 실제 매수 차단 · NOT_VALIDATED</p></section>';}
 root.LucaUI=Object.freeze({...old,normalize,detail,freshness:()=>expired()?'오래된 자료 · 새 수집 전 판단 차단':'완료 일봉 관찰 · 실시간 미연결 · 실제 매수 불가'});
 const d=root.LUCA_PAYLOAD,detailRows=[...d.candidates,...d.additional_rows,...(d.rejected_details||[])];root.LUCA_REAL_ROWS=[...detailRows,...d.light_results.filter(r=>r.light_status==='DATA_BLOCKED'&&!detailRows.some(x=>x.ticker===r.ticker))].map(raw=>({raw,meta:d}));
 })(globalThis);`;
 const guide=`루카 수동 갱신 연구판 사용법\nHTML은 저장된 관찰 자료를 보는 파일입니다. 파일 자체는 새 시세를 수집하지 않습니다.\n새 자료: 컴퓨터에서 python research/refresh.py --collect-once를 한 번 실행한 뒤 local-data/manual-refresh-research/exports/LUCA_REFRESH_IPHONE.html을 아이폰으로 전달하세요.\n기존 자료로 화면만 다시 만들려면 --rebuild를 사용하세요. 인터넷 수집 없음.\n아이폰 파일 앱 미리보기에서는 버튼이 제한될 수 있습니다. Safari 실제 기기 시험은 미완료입니다. 지원되는 브라우저에서 열거나 아래 정적 상세를 보세요.\n검색/등급/유형 필터를 누른 뒤 종목 자세히 보기를 선택하세요.\n정규장 완료 일봉만 연결. 데이장/프리/애프터 실시간 미연결. 모든 실제 매수 차단, 가격 계획 산출 불가, NOT_VALIDATED.\n1달러 미만 긴 숫자는 원본 정밀도이며 실제 주문 가격 단위가 아닙니다.\n`;
 let app=read('app.js').replace("+'개 · 상세 분석 14개 + 일봉 차단 3개'",()=>`+'개 · 상세 분석 ${detail.length}개 · 자료 차단 별도 표시'`);
 const scripts=[read('model.js'),inputs,model,extension,'globalThis.LUCA_GUIDE='+JSON.stringify(guide)+';',app];
 for(const s of scripts.slice(1))vm.runInContext(s,c);
 const rows=c.LUCA_REAL_ROWS.map(c.LucaUI.normalize),counts=c.LucaUI.counts(rows);
 const failed=status.status==='FAILED_LAST_SUCCESS_RETAINED',baseline=status.status==='BASELINE_ONLY';
 const stale=!Number.isFinite(Date.parse(proof.valid_until))||Date.now()>=Date.parse(proof.valid_until);
 const statusText=failed?'갱신 실패 · 마지막 성공 자료를 표시합니다':baseline?'새 수집 전 · 이전 검수 자료입니다':stale?'과거 수집 완료 자료 · 유효기간 만료 · 현재 판단 불가':proof.scope_partial?'새 수집 완료 · 조사 범위 부족':'새 수집 완료';
 const summary=`${failed||baseline||stale?'이전 성공 자료 · ':''}조사 ${d.attempted_count}개 · 일봉 확인 ${proof.verified_light}개 · 상세 ${detail.length}개`;
 const outcome=proof.outcome==='CANNOT_DETERMINE_ZERO'?'자료 부족으로 정식 후보 0개를 확정할 수 없습니다':proof.outcome==='ZERO_IN_VERIFIED_SCOPE'?'검증한 조사 범위에서 정식 후보 0개 · 전체 시장 후보 0개라는 뜻은 아닙니다':`검증 원본 정식 관찰 ${proof.formal_count}개 · 매수 추천 아님`;
 let html=read('index.html');
 html=html.replace(/<p class="notice">조사[\s\S]*?<\/p>/,()=>`<p class="notice">${summary}<br>${outcome}<br>실전 성과 NOT_VALIDATED</p>`);
 html=html.replace(/<aside class="banner">[\s\S]*?<\/aside>/,()=>`<aside class="banner"><strong>${statusText}</strong><p>주가 기준: 미국 ${esc(d.session)} 완료 정규장 일봉<br>수집 시작: ${esc(M.time(d.collection_started_at))}<br>선정 완료: ${esc(M.time(d.selection_known_at))}</p><p>이번 갱신 시도: ${esc(M.time(status.started_at))}<br>${failed?'실패 원인: '+esc(status.reason||'미확인'):''}</p><p>시가총액 3억 달러 이하 공개 순위 표본 · 현재 초소형주 적격성은 추가 확인 필요. 최대 100종목 조사/25종목 상세. 기존 5거래일 시험과 별도.</p></aside>`);
 html=html.replace(/<p class="hint">A\/B\/C\/D[\s\S]*?<\/p>/,()=>'<p class="hint">등급은 관찰 우선순위입니다. A는 미사용. B/C는 검증한 수집 당시 조건이며 안전성·매수 허가가 아닙니다. 다음 거래일 마감 후에는 새 수집 전 D로 차단됩니다.</p>');
 for(const g of ['A','B','C','D'])html=html.replace(new RegExp(`(id="count-${g}">)\\d+`),(_,a)=>a+counts[g]);
 html=html.replace('상세 분석 14개 + 일봉 차단 3개',summary);
 html=html.replace('2026-10-16 완료 일봉 저장본',esc(d.session)+' 완료 일봉 저장본');
 html=html.replace(/<p class="hint">미국 정규장 마감[\s\S]*?<\/p>/,()=>`<p class="hint">새 완료 거래일 경계: ${esc(M.time(proof.valid_until))}. 임시 휴장은 별도 확인 필요. 실시간 시세는 모든 시간대 미연결.</p>`);
 html=html.replace(/<p>수집 시작:[\s\S]*?<\/p>/,()=>`<p>마지막 검증 수집: ${esc(M.time(d.selection_known_at))}<br>가격 기준: ${esc(d.session)} 정규장 완료 일봉<br>HTML 내부에서는 시세를 갱신하지 않습니다. 컴퓨터에서 별도 수집 후 새 HTML을 전달해야 합니다.</p>`);
 html=html.replaceAll('<p class="warning">데이터 미연결</p>','<p class="warning">실시간 미연결</p>');
 html=html.replace('<!--PRERENDER-->',()=>rows.map(c.LucaUIApp.card).join(''));
 html=html.replace('<link rel="stylesheet" href="style.css">',()=>'<style>'+read('style.css')+' small{overflow-wrap:anywhere}</style>');
 html=html.replace(/<script src="[^"]+"><\/script>/g,'');
 html=html.replace('</body>',()=>scripts.map(s=>'<script>'+s.replace(/<\/script/gi,'<\\/script')+'</script>').join('')+'</body>');
 html=html.replace(/<noscript>[\s\S]*?<\/noscript>/,()=>'<noscript><section class="wrap"><h2>버튼 실행 미지원 · 생성 당시 정적 자료</h2><p>자료 생성 이후의 날짜 검사는 실행되지 않습니다. 아래는 과거 저장 내용이며 현재 판단에 사용하지 마세요.</p>'+rows.map(r=>'<details><summary>'+esc(r.ticker)+' 상세</summary>'+c.LucaUI.detail(r)+'</details>').join('')+'</section></noscript>');
 return html;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const packet=JSON.parse(fs.readFileSync(0,'utf8'));const html=render(packet);const dest=process.argv[2];fs.writeFileSync(dest+'.tmp',html);fs.renameSync(dest+'.tmp',dest);
}
