#!/usr/bin/env python3
"""Independent, free-tier static-site adapter. No order execution; no existing repo/site mutation.
It does NOT change or weaken the verified collector. Failure never promotes old data.
"""
import argparse
import datetime as dt
import json
import os
import pathlib
import re
import shutil
import sys

ROOT = pathlib.Path(__file__).resolve().parent
ENGINE = ROOT / 'engine'
DOCS = ROOT / 'docs'
SYS_TOKEN_RE = re.compile(r'(?:sk-[A-Za-z0-9_-]{10,}|gh[pousr]_[A-Za-z0-9_]+)', re.I)


def iso_now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
    tmp.replace(path)


def read_previous():
    try:
        prev = json.loads((DOCS/'status.json').read_text(encoding='utf8'))
    except (OSError, ValueError):
        prev = {}
    # An older successful page may be retained, but never relabeled as new.
    return prev.get('last_success') if isinstance(prev.get('last_success'), dict) else None


def make_failure(reason, started_at=None, *, diagnostic=None):
    reason = SYS_TOKEN_RE.sub('[비공개]', str(reason))[:240]
    payload = {
        'version': 1, 'status': 'FAILED_LAST_SUCCESS_RETAINED',
        'outcome': 'CANNOT_DETERMINE_ZERO',
        'checked_at_utc': iso_now(), 'started_at_utc': started_at or iso_now(),
        'success_this_run': False, 'real_trades_allowed': False,
        'validation_status': 'NOT_VALIDATED', 'reason': reason,
        'last_success': read_previous(),
        'research_only': True, 'realtime': False,
    }
    if diagnostic: payload['diagnostic'] = diagnostic
    return payload


def ensure_artifacts(home):
    import run_local  # imported from our isolated engine only
    if not home.is_relative_to(run_local.BASE.resolve()):
        raise ValueError('실행 폴더 분리 위반')
    supfile = home/'supervisor-result.json'
    if not supfile.is_file():raise ValueError('감독기 종료 결과 없음')
    s = json.loads(supfile.read_text(encoding='utf8'))
    if not all([s.get('status')=='FINISHED_VERIFIED',
                s.get('successful_refresh') is True,
                s.get('manifest_verified') is True,
                s.get('exit_code')==0]):
        raise ValueError('실제 갱신 최종 성공 증거 없음')
    html = home/'exports/LUCA_REFRESH_IPHONE.html'
    if not html.is_file() or html.stat().st_size < 3000:
        raise ValueError('새 아이폰 HTML 누락')
    state = json.loads((home/'state.json').read_text(encoding='utf8'))
    last = state.get('last_attempt', {})
    if last.get('status') not in ('SUCCESS','SUCCESS_PARTIAL'):
        raise ValueError('실제 attempt 완료 상태 누락')
    if last.get('attempt_id') not in {path.name for path in (home/'attempts').glob('*')}:
        raise ValueError('실제 attempt ID 원본 폴더 누락')
    if not state.get('history','').startswith('attempts/'):
        raise ValueError('기존 자료를 새 성공으로 사용할 수 없음')
    proof_path=html.with_suffix('.proof.json')
    if not proof_path.is_file():raise ValueError('검증 보고서 누락')
    proof=json.loads(proof_path.read_text(encoding='utf8'))
    # Independently rerun the engine's raw-receipt + completion binding check.
    # Never trust supervisor exit-code or an HTML label alone.
    os.environ['LUCA_RESEARCH_HOME'] = str(home)
    sys.path.insert(0, str(ENGINE/'research'))
    import refresh
    history=(home/state['history']).resolve()
    manifest=(history/state['manifest']).resolve()
    confirmed=refresh.completion_check(history,manifest,last)
    if confirmed.get('verified') is not True or s.get('completion')!=confirmed:
        raise ValueError('감독기 완료 증거와 원본 재검증 결과 불일치')
    _, recalculated=refresh.verify(history,manifest,require_current=True)
    if proof!=recalculated:
        raise ValueError('HTML 생성시 검증 근거와 현재 디스크 근거 불일치')
    # This proof was produced by the engine, not by a fake status string.
    if proof.get('entryAllowed') is not False or proof.get('validationStatus')!='NOT_VALIDATED':
        raise ValueError('매수 차단 증거 누락')
    return s,last,html,proof


def publish_verified(home,started_at):
    supervisor, last, html, proof=ensure_artifacts(home)
    DOCS.mkdir(parents=True, exist_ok=True)
    tmp=DOCS/'latest.html.tmp'
    shutil.copyfile(html,tmp)
    tmp.replace(DOCS/'latest.html')
    success = {
        'collected_at_utc': iso_now(),
        'session': last.get('session'),
        'attempt_id': last.get('attempt_id'),
        'dated': last.get('dated'),
        'details': last.get('details'),
        'formal': last.get('formal'),
        'scope_partial': last.get('status')=='SUCCESS_PARTIAL',
        'outcome': last.get('outcome'),
        'source_type': 'COMPLETED_DAILY_BARS',
        'url': './latest.html'
    }
    result={
        'version':1,'status':'SUCCESS_RESEARCH_OBSERVATION',
        'outcome':last.get('outcome', 'CANNOT_DETERMINE_ZERO'),
        'checked_at_utc':iso_now(), 'started_at_utc':started_at,
        'success_this_run':True,'last_success':success,
        'real_trades_allowed':False,'validation_status':'NOT_VALIDATED',
        'realtime':False,'research_only':True,
    }
    write_json(DOCS/'status.json',result)
    return result


def run_once():
    started_at=iso_now()
    sys.path.insert(0,str(ENGINE))
    home=None
    try:
        import run_local
        home=run_local.prepare()  # verifies immutable archived baseline first
        exit_code=run_local.collect(home)  # exactly one monitored real collection
        if exit_code!=0:
            preflight=home/'preflight-failure.json'
            if preflight.is_file():
                raise RuntimeError('무료 주가 제공처 DNS 연결 실패 · 이번 신규 수집 시작하지 못함')
            raise RuntimeError('수집 종료 코드 '+str(exit_code)+' · 감독/자료/시간 검증 로그 확인 필요')
        result=publish_verified(home,started_at)
        print('LUCA_RESULT: VERIFIED_EOD_OBSERVATION',result['last_success']['session'])
        return 0
    except Exception as ex:
        diagnostic=None
        if home is not None:
            s=home/'supervisor-result.json'
            if s.is_file():
                try:
                    d=json.loads(s.read_text(encoding='utf8'))
                    diagnostic={'supervisor_status':d.get('status'),
                                'supervisor_outcome':d.get('outcome')}
                except (OSError,ValueError):pass
        result=make_failure(type(ex).__name__+': '+str(ex),started_at,diagnostic=diagnostic)
        write_json(DOCS/'status.json', result)
        print('LUCA_RESULT: FAILED / CANNOT_DETERMINE_ZERO', result['reason'])
        return 1


def offline_check():
    # Only archived baseline data, no network, no new market claims.
    sys.path.insert(0,str(ENGINE))
    import run_local
    home=run_local.prepare()
    html=home/'exports/LUCA_REFRESH_IPHONE.html'
    assert html.is_file() and html.stat().st_size > 3000
    print('OFFLINE_OK: 과거 실제 자료로 HTML 재생성 성공 / 최신 갱신 아님')
    return 0


def main():
    parser=argparse.ArgumentParser(description='루카 무료 GitHub Pages 연구판: 주문·실시간 신호 없음')
    parser.add_argument('action',choices=['once','offline-check'])
    args=parser.parse_args()
    return run_once() if args.action=='once' else offline_check()

if __name__=='__main__':sys.exit(main())
