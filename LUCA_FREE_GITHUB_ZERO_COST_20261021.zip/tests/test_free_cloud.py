import importlib.util, json, pathlib, tempfile, unittest
from unittest import mock
ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cloud_adapter', ROOT/'run_free_cloud.py')
adapter = importlib.util.module_from_spec(spec)
spec.loader.exec_module(adapter)

class FailClosedTests(unittest.TestCase):
    def test_initial_no_buy(self):
        data=json.loads((ROOT/'docs/status.json').read_text())
        self.assertIs(data['real_trades_allowed'], False)
        self.assertEqual(data['validation_status'],'NOT_VALIDATED')

    def test_fail_keeps_last_success_not_marking_fresh(self):
        with tempfile.TemporaryDirectory() as t:
            with mock.patch.object(adapter,'DOCS',pathlib.Path(t)):
                (pathlib.Path(t)/'status.json').write_text(json.dumps({
                    'last_success':{'session':'2026-10-16','formal':1,'collected_at_utc':'2026-10-19T00:00:00+00:00'}}))
                result=adapter.make_failure('HTTP 403', '2026-10-21T00:00:00+00:00')
                self.assertEqual(result['status'],'FAILED_LAST_SUCCESS_RETAINED')
                self.assertEqual(result['outcome'],'CANNOT_DETERMINE_ZERO')
                self.assertFalse(result['success_this_run'])
                self.assertEqual(result['last_success']['session'],'2026-10-16')

    def test_no_completion_rejects_forged_supervisor(self):
        with tempfile.TemporaryDirectory() as t:
            home=pathlib.Path(t)/'fake';home.mkdir()
            with self.assertRaisesRegex(ValueError,'분리 위반'):
                adapter.ensure_artifacts(home)

    def test_initial_page_labels_unverified(self):
        s=(ROOT/'docs/index.html').read_text()
        for phrase in ['NOT_VALIDATED','현재 실전 매수 허용 0건','실시간 시세 아님','판단 불가','status.json']:
            self.assertIn(phrase,s)

    def test_failing_run_does_not_persist_false_success(self):
        with tempfile.TemporaryDirectory() as t:
            home=pathlib.Path(t)
            with mock.patch.object(adapter,'DOCS',home/'docs'):
                with mock.patch.dict('sys.modules', {'run_local': None}):
                    # No meaningful fake imports; failure must still be recorded.
                    code=adapter.run_once()
                self.assertEqual(code,1)
                r=json.loads((home/'docs/status.json').read_text())
                self.assertFalse(r['success_this_run'])
                self.assertFalse((home/'docs/latest.html').exists())

if __name__=='__main__':unittest.main()
